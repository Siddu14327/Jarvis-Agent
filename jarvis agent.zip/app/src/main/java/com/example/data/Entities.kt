package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "episodes")
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val origin: String,
    val perception: String,
    val action: String,
    val outcome: String,
    val success: Boolean
)

@Entity(
    tableName = "pheromone_trails",
    indices = [Index(value = ["patternKey"], unique = true)]
)
data class PheromoneTrailEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val patternKey: String,
    val actionSequenceJson: String,
    val pheromoneStrength: Float = 1.0f,
    val encounterCount: Int = 1,
    val successCount: Int = 1,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "voice_identity")
data class VoiceIdentityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileName: String,
    val pitchFrequencyHz: Float,
    val energyVariance: Float,
    val confidenceThreshold: Float = 0.70f,
    val isEnrolled: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "agent_facts",
    indices = [Index(value = ["key"], unique = true)]
)
data class AgentMemoryFact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val key: String,
    val value: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "file_artifacts")
data class FileArtifactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uriString: String,
    val fileName: String,
    val mimeType: String,
    val fileSize: Long,
    val fileCategory: String, // IMAGE, VIDEO, AUDIO, PDF, TEXT, ARCHIVE, BINARY
    val decodedSummary: String,
    val detailedMetadata: String,
    val timestamp: Long = System.currentTimeMillis()
)
