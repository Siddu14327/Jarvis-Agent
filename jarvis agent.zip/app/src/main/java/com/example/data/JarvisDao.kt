package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {

    // --- Episodes ---
    @Query("SELECT * FROM episodes ORDER BY timestamp DESC LIMIT 100")
    fun getRecentEpisodes(): Flow<List<EpisodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisode(episode: EpisodeEntity): Long

    @Query("DELETE FROM episodes")
    suspend fun clearEpisodes()

    // --- Pheromone Trails (Ant/Bee Adaptation Memory) ---
    @Query("SELECT * FROM pheromone_trails ORDER BY pheromoneStrength DESC")
    fun getAllPheromoneTrails(): Flow<List<PheromoneTrailEntity>>

    @Query("SELECT * FROM pheromone_trails WHERE patternKey = :patternKey LIMIT 1")
    suspend fun getTrail(patternKey: String): PheromoneTrailEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrail(trail: PheromoneTrailEntity)

    @Update
    suspend fun updateTrail(trail: PheromoneTrailEntity)

    @Query("DELETE FROM pheromone_trails WHERE pheromoneStrength < 0.1")
    suspend fun pruneWeakTrails()

    // --- Voice Identity ---
    @Query("SELECT * FROM voice_identity LIMIT 1")
    fun getVoiceProfile(): Flow<VoiceIdentityEntity?>

    @Query("SELECT * FROM voice_identity LIMIT 1")
    suspend fun getVoiceProfileSync(): VoiceIdentityEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveVoiceProfile(profile: VoiceIdentityEntity)

    // --- Agent Memory Facts ---
    @Query("SELECT * FROM agent_facts ORDER BY timestamp DESC")
    fun getAllFacts(): Flow<List<AgentMemoryFact>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFact(fact: AgentMemoryFact)

    @Query("DELETE FROM agent_facts WHERE `key` = :key")
    suspend fun deleteFact(key: String)

    // --- File Artifacts ---
    @Query("SELECT * FROM file_artifacts ORDER BY timestamp DESC")
    fun getAllFileArtifacts(): Flow<List<FileArtifactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFileArtifact(artifact: FileArtifactEntity): Long

    @Query("DELETE FROM file_artifacts WHERE id = :id")
    suspend fun deleteFileArtifact(id: Long)
}
