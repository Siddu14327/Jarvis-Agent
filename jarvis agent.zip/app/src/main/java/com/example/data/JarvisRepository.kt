package com.example.data

import kotlinx.coroutines.flow.Flow

class JarvisRepository(private val dao: JarvisDao) {

    val recentEpisodes: Flow<List<EpisodeEntity>> = dao.getRecentEpisodes()
    val pheromoneTrails: Flow<List<PheromoneTrailEntity>> = dao.getAllPheromoneTrails()
    val voiceProfile: Flow<VoiceIdentityEntity?> = dao.getVoiceProfile()
    val agentFacts: Flow<List<AgentMemoryFact>> = dao.getAllFacts()

    suspend fun recordEpisode(
        origin: String,
        perception: String,
        action: String,
        outcome: String,
        success: Boolean
    ): Long {
        return dao.insertEpisode(
            EpisodeEntity(
                origin = origin,
                perception = perception,
                action = action,
                outcome = outcome,
                success = success
            )
        )
    }

    suspend fun clearEpisodes() = dao.clearEpisodes()

    // Ant/Bee Pheromone updates
    suspend fun reinforceTrail(patternKey: String, actionSequenceJson: String, success: Boolean) {
        val existing = dao.getTrail(patternKey)
        if (existing == null) {
            val initialStrength = if (success) 1.5f else 0.5f
            dao.upsertTrail(
                PheromoneTrailEntity(
                    patternKey = patternKey,
                    actionSequenceJson = actionSequenceJson,
                    pheromoneStrength = initialStrength,
                    encounterCount = 1,
                    successCount = if (success) 1 else 0
                )
            )
        } else {
            val newStrength = if (success) {
                existing.pheromoneStrength + 0.5f
            } else {
                (existing.pheromoneStrength * 0.7f).coerceAtLeast(0.05f)
            }
            dao.updateTrail(
                existing.copy(
                    actionSequenceJson = if (success) actionSequenceJson else existing.actionSequenceJson,
                    pheromoneStrength = newStrength,
                    encounterCount = existing.encounterCount + 1,
                    successCount = if (success) existing.successCount + 1 else existing.successCount,
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun getTrail(patternKey: String): PheromoneTrailEntity? {
        return dao.getTrail(patternKey)
    }

    suspend fun saveVoiceProfile(profile: VoiceIdentityEntity) {
        dao.saveVoiceProfile(profile)
    }

    suspend fun getVoiceProfileSync(): VoiceIdentityEntity? {
        return dao.getVoiceProfileSync()
    }

    suspend fun rememberFact(category: String, key: String, value: String) {
        dao.upsertFact(AgentMemoryFact(category = category, key = key, value = value))
    }

    val fileArtifacts: Flow<List<FileArtifactEntity>> = dao.getAllFileArtifacts()

    suspend fun recordFileArtifact(artifact: FileArtifactEntity): Long = dao.insertFileArtifact(artifact)

    suspend fun deleteFileArtifact(id: Long) = dao.deleteFileArtifact(id)
}
