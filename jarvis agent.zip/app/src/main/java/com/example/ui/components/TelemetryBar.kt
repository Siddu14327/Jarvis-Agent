package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.senses.DeviceTelemetry
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun TelemetryBar(
    telemetry: DeviceTelemetry,
    isAccessibilityConnected: Boolean,
    isCameraReady: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceCard, RoundedCornerShape(12.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Battery (Body)
        TelemetryItem(
            icon = if (telemetry.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
            label = "${telemetry.batteryPercent}%",
            color = if (telemetry.batteryPercent > 20) EmeraldGreen else CrimsonRed
        )

        // Hands (Accessibility)
        TelemetryItem(
            icon = Icons.Default.PanTool,
            label = if (isAccessibilityConnected) "HANDS ON" else "HANDS OFF",
            color = if (isAccessibilityConnected) ArcCyan else CrimsonRed
        )

        // Eyes (Camera)
        TelemetryItem(
            icon = Icons.Default.RemoveRedEye,
            label = if (isCameraReady) "OPTICS ON" else "OPTICS OFF",
            color = if (isCameraReady) ArcCyan else TextMuted
        )

        // Network
        TelemetryItem(
            icon = Icons.Default.Wifi,
            label = if (telemetry.networkType.contains("Wi-Fi")) "WIFI" else "NET",
            color = if (telemetry.networkType != "Offline") EmeraldGreen else CrimsonRed
        )

        // RAM
        TelemetryItem(
            icon = Icons.Default.Memory,
            label = "${telemetry.memoryUsagePercent}% RAM",
            color = ArcCyan
        )
    }
}

@Composable
private fun TelemetryItem(
    icon: ImageVector,
    label: String,
    color: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = color,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = TextPrimary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}
