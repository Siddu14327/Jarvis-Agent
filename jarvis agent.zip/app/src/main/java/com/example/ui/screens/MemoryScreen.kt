package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.service.JarvisForegroundService
import com.example.data.EpisodeEntity
import com.example.data.PheromoneTrailEntity
import com.example.ui.JarvisViewModel
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.ArcGold
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DeepVoidSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceSlate
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MemoryScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val pheromoneTrails by viewModel.pheromoneTrails.collectAsState()
    val episodes by viewModel.recentEpisodes.collectAsState()
    val voiceProfile by viewModel.voiceProfile.collectAsState()

    var enrollmentName by remember { mutableStateOf("") }
    var isServiceRunning by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Column {
            Text(
                text = "NEURAL MEMORY & ADAPTATION",
                fontSize = 15.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = ArcCyan,
                letterSpacing = 1.sp
            )
            Text(
                text = "Biological ant/bee swarm intelligence & persistent memory core",
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        // Persistent Agent Background Service Control
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                .testTag("persistent_service_card"),
            color = SurfaceCard,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PERSISTENT AGENT CONSCIOUSNESS",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = ArcCyan
                        )
                        Text(
                            text = "Operate outside app via Android Foreground Service",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                    Button(
                        onClick = {
                            if (isServiceRunning) {
                                JarvisForegroundService.stopService(context)
                                isServiceRunning = false
                            } else {
                                JarvisForegroundService.startService(context)
                                isServiceRunning = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isServiceRunning) CrimsonRed else EmeraldGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("toggle_service_button")
                    ) {
                        Icon(
                            imageVector = if (isServiceRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isServiceRunning) "DISENGAGE" else "ENGAGE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Ant & Bee Swarm Intelligence Section
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                .testTag("ant_bee_swarm_card"),
            color = SurfaceCard,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ANT & BEE PHEROMONE TRAILS (${pheromoneTrails.size})",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = ArcCyan
                    )
                    Text(
                        text = "ADAPTIVE REINFORCEMENT",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ArcGold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "When solving tasks without hard-coded scripts, JARVIS formulates hypotheses, executes actions through phone controls, and reinforces successful paths with digital pheromones while decaying failed paths.",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))
                if (pheromoneTrails.isEmpty()) {
                    Text(
                        text = "No pheromone trails deposited yet. Issue commands (e.g., 'Find petrol station') to initiate adaptive foraging.",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    pheromoneTrails.take(5).forEach { trail ->
                        PheromoneTrailRow(trail)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        // Voice Identity Subsystem
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                .testTag("voice_identity_card"),
            color = SurfaceCard,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "VOICE IDENTITY SUBSYSTEM",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ArcCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Acoustic biometric verification protecting sensitive system directives.",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(10.dp))
                if (voiceProfile != null && voiceProfile?.isEnrolled == true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Enrolled Profile: ${voiceProfile?.profileName} (Baseline Pitch: ${voiceProfile?.pitchFrequencyHz?.toInt()} Hz)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = enrollmentName,
                            onValueChange = { enrollmentName = it },
                            placeholder = { Text("Enter user name...", fontSize = 11.sp, color = TextMuted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ArcCyan,
                                unfocusedBorderColor = BorderSubtle,
                                focusedContainerColor = DeepVoidSlate,
                                unfocusedContainerColor = DeepVoidSlate
                            )
                        )
                        Button(
                            onClick = {
                                if (enrollmentName.isNotBlank()) {
                                    viewModel.enrollVoiceProfile(enrollmentName)
                                    enrollmentName = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ENROLL", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Recent Episodes History
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp)),
            color = SurfaceCard,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "RECENT EPISODIC MEMORY (${episodes.size})",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ArcCyan
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (episodes.isEmpty()) {
                    Text(
                        text = "Memory database clear. Interacting with JARVIS records persistent operational episodes.",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                } else {
                    episodes.take(8).forEach { ep ->
                        EpisodeRow(ep)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun PheromoneTrailRow(trail: PheromoneTrailEntity) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(DeepVoidSlate)
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = trail.patternKey,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = ArcCyan
            )
            Text(
                text = "Strength: %.2f".format(trail.pheromoneStrength),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = ArcGold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (trail.pheromoneStrength / 3.0f).coerceIn(0.05f, 1.0f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = ArcGold,
            trackColor = BorderSubtle
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Encounters: ${trail.encounterCount} // Success Rate: ${((trail.successCount.toFloat() / trail.encounterCount) * 100).toInt()}%",
            fontSize = 10.sp,
            color = TextMuted,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun EpisodeRow(ep: EpisodeEntity) {
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ep.timestamp))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(DeepVoidSlate)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (ep.success) Icons.Default.CheckCircle else Icons.Default.FiberManualRecord,
            contentDescription = null,
            tint = if (ep.success) EmeraldGreen else CrimsonRed,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "[$timeStr] ${ep.action}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextPrimary
            )
            Text(
                text = ep.outcome,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1
            )
        }
    }
}
