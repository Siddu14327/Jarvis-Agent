package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = ArcCyan,
    onPrimary = Color(0xFF001E2B),
    primaryContainer = Color(0xFF00364C),
    onPrimaryContainer = Color(0xFF9CF0FF),
    secondary = ArcGold,
    onSecondary = Color(0xFF261900),
    secondaryContainer = Color(0xFF402E00),
    onSecondaryContainer = Color(0xFFFFE082),
    tertiary = PlasmaBlue,
    onTertiary = Color.White,
    background = ObsidianBlack,
    onBackground = TextPrimary,
    surface = DeepVoidSlate,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceSlate,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = Color(0xFF0D1726)
)

@Composable
fun JarvisTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // JARVIS is fundamentally an agent HUD engineered in cybernetic dark aesthetic
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
