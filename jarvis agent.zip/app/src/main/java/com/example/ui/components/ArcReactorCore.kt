package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.brain.AgentMode
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.ArcGold
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PlasmaBlue
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorCore(
    mode: AgentMode,
    audioEnergy: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val primaryColor = when (mode) {
        AgentMode.IDLE -> ArcCyan
        AgentMode.LISTENING -> ArcGold
        AgentMode.ANALYZING -> PlasmaBlue
        AgentMode.EXECUTING_ACTION -> EmeraldGreen
        AgentMode.SPEAKING -> ArcCyan
        AgentMode.INSPECTING_VISION -> CrimsonRed
    }

    Box(
        modifier = modifier
            .size(220.dp)
            .testTag("arc_reactor_core"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(200.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.width / 2.3f

            // Dynamic scale influenced by audio energy when listening/speaking
            val dynamicScale = if (mode == AgentMode.LISTENING || mode == AgentMode.SPEAKING) {
                1.0f + (audioEnergy * 0.25f)
            } else {
                pulse
            }

            // Outer Tech Glow Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(primaryColor.copy(alpha = 0.25f), Color.Transparent),
                    center = center,
                    radius = baseRadius * 1.3f
                ),
                radius = baseRadius * 1.25f,
                center = center
            )

            // Outer segmented ring
            drawCircle(
                color = primaryColor.copy(alpha = 0.7f),
                radius = baseRadius,
                center = center,
                style = Stroke(
                    width = 2.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 10f), rotation)
                )
            )

            // Middle counter-rotating ring
            drawCircle(
                color = primaryColor.copy(alpha = 0.5f),
                radius = baseRadius * 0.75f,
                center = center,
                style = Stroke(
                    width = 1.8f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 12f), counterRotation)
                )
            )

            // Arc Reactor Triangle Points / Spokes
            val spokeCount = 8
            for (i in 0 until spokeCount) {
                val angle = Math.toRadians((rotation + (i * 360f / spokeCount)).toDouble())
                val innerR = baseRadius * 0.45f
                val outerR = baseRadius * 0.95f
                val start = Offset(
                    (center.x + innerR * cos(angle)).toFloat(),
                    (center.y + innerR * sin(angle)).toFloat()
                )
                val end = Offset(
                    (center.x + outerR * cos(angle)).toFloat(),
                    (center.y + outerR * sin(angle)).toFloat()
                )
                drawLine(
                    color = primaryColor.copy(alpha = 0.6f),
                    start = start,
                    end = end,
                    strokeWidth = 2f
                )
            }

            // Core Glow Center
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, primaryColor, primaryColor.copy(alpha = 0.1f)),
                    center = center,
                    radius = baseRadius * 0.4f * dynamicScale
                ),
                radius = baseRadius * 0.38f * dynamicScale,
                center = center
            )

            // Center Point
            drawCircle(
                color = Color.White,
                radius = 6f,
                center = center
            )
        }

        // Mode Status Overlay
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(130.dp))
            Text(
                text = mode.name.replace('_', ' '),
                color = primaryColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }
    }
}
