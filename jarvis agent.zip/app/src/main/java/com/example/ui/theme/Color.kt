package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ArcCyan = Color(0xFF00E5FF)
val ArcCyanDark = Color(0xFF00B0FF)
val ArcCyanGlow = Color(0x3300E5FF)
val ArcGold = Color(0xFFFFD54F)
val ArcGoldDark = Color(0xFFFFB300)
val PlasmaBlue = Color(0xFF448AFF)
val EmeraldGreen = Color(0xFF00E676)
val CrimsonRed = Color(0xFFFF1744)

val ObsidianBlack = Color(0xFF06090F)
val DeepVoidSlate = Color(0xFF0A101C)
val SurfaceSlate = Color(0xFF10192A)
val SurfaceCard = Color(0xFF142138)
val SurfaceCardHighlight = Color(0xFF1B2C4B)
val BorderSubtle = Color(0xFF1E3252)
val BorderGlow = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B9EB7)
val TextMuted = Color(0xFF536780)
