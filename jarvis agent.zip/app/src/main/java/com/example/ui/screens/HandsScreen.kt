package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisViewModel
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.ArcGold
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DeepVoidSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceSlate
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HandsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isAccessibilityConnected by viewModel.isAccessibilityConnected.collectAsState()
    val activePackage by viewModel.activePackage.collectAsState()
    val activeTitle by viewModel.activeWindowTitle.collectAsState()
    val report by viewModel.screenReport.collectAsState()

    var manualSearchText by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DIGITAL HANDS & SCREEN",
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ArcCyan,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Autonomous cross-app navigation & UI comprehension",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
            IconButton(onClick = { viewModel.refreshScreenReport() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh Screen State", tint = ArcCyan)
            }
        }

        // Accessibility Service Status Banner
        if (!isAccessibilityConnected) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ArcGold, RoundedCornerShape(12.dp))
                    .testTag("accessibility_banner"),
                color = SurfaceCard,
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ACCESSIBILITY PERMISSION REQUIRED",
                        color = ArcGold,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "To allow JARVIS to understand your screen, tap buttons, and operate external apps, please enable JARVIS in Accessibility Settings.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ArcGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("enable_accessibility_button")
                    ) {
                        Text("OPEN ACCESSIBILITY SETTINGS", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        } else {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, EmeraldGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                color = SurfaceCard,
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(EmeraldGreen)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NEURAL ACCESSIBILITY INTERFACE ACTIVE",
                        color = EmeraldGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Active Screen Comprehension Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                .testTag("screen_perception_card"),
            color = SurfaceCard,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "SCREEN PERCEPTION STATUS",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ArcCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Target App: ${report?.appDisplayName ?: "Unknown"} ($activePackage)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = report?.summary ?: "Scanning window hierarchy...",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )

                if (!report?.actionableButtons.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "DETECTED CONTROLS (${report?.actionableButtons?.size}):",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ArcGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        report?.actionableButtons?.forEach { btnText ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DeepVoidSlate)
                                    .border(1.dp, BorderSubtle, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.performSystemAction("CLICK_TEXT", btnText) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "TAP: $btnText",
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Real Android Applications Deck
        Column {
            Text(
                text = "REAL APPLICATION TRANSCEIVERS",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLauncherTile(
                    title = "Google Maps",
                    subtitle = "Navigate & Places",
                    icon = Icons.Default.Map,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.performSystemAction("LAUNCH_MAPS", "petrol station")
                }
                AppLauncherTile(
                    title = "YouTube",
                    subtitle = "Media Stream",
                    icon = Icons.Default.PlayArrow,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.performSystemAction("LAUNCH_YOUTUBE", "")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLauncherTile(
                    title = "Web Browser",
                    subtitle = "Live Search",
                    icon = Icons.Default.Language,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.performSystemAction("LAUNCH_BROWSER", "https://google.com")
                }
                AppLauncherTile(
                    title = "Phone Dialer",
                    subtitle = "Communications",
                    icon = Icons.Default.Phone,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.performSystemAction("LAUNCH_DIALER", "")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLauncherTile(
                    title = "Camera",
                    subtitle = "Hardware Optics",
                    icon = Icons.Default.CameraAlt,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.performSystemAction("LAUNCH_CAMERA")
                }
                AppLauncherTile(
                    title = "Calculator",
                    subtitle = "Computation",
                    icon = Icons.Default.Calculate,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.performSystemAction("LAUNCH_CALCULATOR")
                }
            }
        }

        // Global Navigation Controls
        Column {
            Text(
                text = "SYSTEM NAVIGATION ACTUATORS",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NavButton(label = "BACK", icon = Icons.AutoMirrored.Filled.ArrowBack, modifier = Modifier.weight(1f)) {
                    viewModel.performSystemAction("BACK")
                }
                NavButton(label = "HOME", icon = Icons.Default.Home, modifier = Modifier.weight(1f)) {
                    viewModel.performSystemAction("HOME")
                }
                NavButton(label = "NOTIFS", icon = Icons.Default.Notifications, modifier = Modifier.weight(1f)) {
                    viewModel.performSystemAction("NOTIFICATIONS")
                }
                NavButton(label = "SCROLL", icon = Icons.Default.VerticalAlignBottom, modifier = Modifier.weight(1f)) {
                    viewModel.performSystemAction("SCROLL")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun AppLauncherTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = SurfaceCard,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DeepVoidSlate),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = ArcCyan, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(text = subtitle, fontSize = 10.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun NavButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextPrimary),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
            .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
            .height(44.dp)
    ) {
        Icon(icon, contentDescription = label, tint = ArcCyan, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
