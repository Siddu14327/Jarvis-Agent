package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.brain.AgentLogEntry
import com.example.agent.brain.AgentMode
import com.example.agent.senses.EarsState
import com.example.ui.JarvisViewModel
import com.example.ui.components.ArcReactorCore
import com.example.ui.components.AttachedFileCard
import com.example.ui.components.TelemetryBar
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.ArcGold
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DeepVoidSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceSlate
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CoreMatrixScreen(
    viewModel: JarvisViewModel,
    onNavigateToFiles: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val agentMode by viewModel.agentMode.collectAsState()
    val thought by viewModel.currentThought.collectAsState()
    val telemetry by viewModel.deviceTelemetry.collectAsState()
    val earsState by viewModel.earsState.collectAsState()
    val rmsLevel by viewModel.earsRms.collectAsState()
    val partialSpeech by viewModel.partialSpeech.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isHandsOn by viewModel.isAccessibilityConnected.collectAsState()
    val isOpticsOn by viewModel.isCameraReady.collectAsState()
    val logs by viewModel.agentLogs.collectAsState()
    val isAutonomousBodyMode by viewModel.autonomousBodyMode.collectAsState()
    val activeFile by viewModel.activeFile.collectAsState()
    val isPlayingAudio by viewModel.isPlayingAudio.collectAsState()

    var commandInput by remember { mutableStateOf("") }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.attachFile(it) }
    }

    val quickCommands = if (activeFile != null) {
        listOf(
            "What is in this file?",
            "Open this file",
            "Summarize this document"
        ) + (if (activeFile?.canPlayAudio == true) listOf("Play attached audio", "Pause audio") else emptyList()) +
        listOf("Go Home", "Diagnostic status")
    } else {
        listOf(
            "Find nearest petrol station",
            "Open Google Maps",
            "Open YouTube",
            "Diagnostic status",
            "Scan active screen",
            "Go Home",
            "Scroll down"
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            TelemetryBar(
                telemetry = telemetry,
                isAccessibilityConnected = isHandsOn,
                isCameraReady = isOpticsOn
            )
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isAutonomousBodyMode) EmeraldGreen.copy(alpha = 0.6f) else BorderSubtle,
                        RoundedCornerShape(10.dp)
                    )
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { viewModel.toggleAutonomousBodyMode() },
                color = SurfaceSlate
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isAutonomousBodyMode) EmeraldGreen else CrimsonRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isAutonomousBodyMode) "BODY CONSCIOUSNESS: ALWAYS LISTENING & OBSERVING" else "BODY CONSCIOUSNESS: PAUSED",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isAutonomousBodyMode) EmeraldGreen else TextMuted
                        )
                    }
                    Text(
                        text = if (isAutonomousBodyMode) "ACTIVE" else "TAP TO AWAKEN",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ArcCyan
                    )
                }
            }
        }

        // Center Arc Reactor Neural Core
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                ArcReactorCore(
                    mode = agentMode,
                    audioEnergy = rmsLevel
                )
            }
        }

        // Neural Thought Box
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                    .testTag("thought_box"),
                color = SurfaceCard,
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NEURAL COGNITION",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = ArcCyan,
                            letterSpacing = 1.5.sp
                        )
                        if (isSpeaking) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Speaking",
                                    tint = ArcCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "TRANSMITTING",
                                    fontSize = 10.sp,
                                    color = ArcCyan,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = thought,
                        fontSize = 14.sp,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )
                    if (partialSpeech.isNotBlank() && earsState is EarsState.Listening) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Hearing: \"$partialSpeech\"",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = ArcGold
                        )
                    }
                }
            }
        }

        // Active File Card in Core HUD
        if (activeFile != null) {
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE ATTACHED DATA",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = ArcGold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "VIEW IN FILES →",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = ArcCyan,
                            modifier = Modifier.clickable { onNavigateToFiles() }
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    AttachedFileCard(
                        fileResult = activeFile!!,
                        isPlayingAudio = isPlayingAudio,
                        onToggleAudio = {
                            activeFile?.let { viewModel.toggleAudioPlayback(it.uri, it.fileName) }
                        },
                        onOpenExternally = {
                            activeFile?.let { viewModel.openFileExternally(it.uri, it.mimeType) }
                        },
                        onDismiss = { viewModel.clearActiveFile() }
                    )
                }
            }
        }

        // Push-to-Talk, Attach File, and Text Input Controls
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Attach File Button
                IconButton(
                    onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceCard)
                        .border(1.dp, if (activeFile != null) ArcCyan else BorderSubtle, RoundedCornerShape(12.dp))
                        .testTag("attach_file_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Attach Any File",
                        tint = if (activeFile != null) ArcCyan else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Voice Listening Button
                Button(
                    onClick = { viewModel.toggleListening() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (earsState is EarsState.Listening) CrimsonRed else ArcCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("voice_listen_button")
                ) {
                    Icon(
                        imageVector = if (earsState is EarsState.Listening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (earsState is EarsState.Listening) "STOP" else "VOICE",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Text Command Input
                OutlinedTextField(
                    value = commandInput,
                    onValueChange = { commandInput = it },
                    placeholder = { Text("Command JARVIS...", color = TextMuted, fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("command_text_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ArcCyan,
                        unfocusedBorderColor = BorderSubtle,
                        focusedContainerColor = SurfaceCard,
                        unfocusedContainerColor = SurfaceCard,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (commandInput.isNotBlank()) {
                                    viewModel.submitTextCommand(commandInput)
                                    commandInput = ""
                                }
                            },
                            modifier = Modifier.testTag("send_command_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Execute Command",
                                tint = ArcCyan
                            )
                        }
                    }
                )
            }
        }

        // Tactical Presets
        item {
            Column {
                Text(
                    text = "TACTICAL DIRECTIVES",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickCommands.forEach { cmd ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceSlate)
                                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                                .clickable { viewModel.submitTextCommand(cmd) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("tactical_preset_${cmd.take(8)}")
                        ) {
                            Text(
                                text = cmd,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Live Activity Terminal Logs
        item {
            Column {
                Text(
                    text = "SYSTEM TELEMETRY LOG",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp)),
                    color = DeepVoidSlate,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.padding(10.dp),
                        reverseLayout = false
                    ) {
                        itemsIndexed(logs, key = { index, log -> "${log.id}_$index" }) { _, log ->
                            LogItemRow(log)
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun LogItemRow(log: AgentLogEntry) {
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))
    val tagColor = when (log.tag) {
        "BRAIN" -> ArcCyan
        "SENSES", "EARS" -> ArcGold
        "HANDS" -> EmeraldGreen
        "EYES" -> CrimsonRed
        "ADAPTATION" -> Color(0xFFE040FB)
        else -> TextSecondary
    }

    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "[$timeStr] ",
            color = TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "[${log.tag}] ",
            color = tagColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = log.message,
            color = TextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )
    }
}
