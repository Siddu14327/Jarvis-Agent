package com.example.ui.screens

import android.view.ViewGroup
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewModelScope
import com.example.agent.brain.AgentMode
import com.example.ui.JarvisViewModel
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DeepVoidSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VisionScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val agentMode by viewModel.agentMode.collectAsState()
    val currentThought by viewModel.currentThought.collectAsState()
    val isCameraReady by viewModel.isCameraReady.collectAsState()

    var customVisualQuery by remember { mutableStateOf("") }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }

    DisposableEffect(lifecycleOwner) {
        previewViewRef?.let {
            viewModel.core.eyes.bindCamera(
                lifecycleOwner = lifecycleOwner,
                previewView = it,
                onAutonomousVisionFrame = { bitmap ->
                    viewModel.core.handleAutonomousVisionFrame(bitmap)
                },
                scope = viewModel.viewModelScope
            )
        }
        onDispose {
            viewModel.core.eyes.unbind()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "OPTICAL CORTEX (EYES)",
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ArcCyan,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Real-time sensory vision & spatial inspection",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
            Text(
                text = if (isCameraReady) "FEED ACTIVE" else "INITIALIZING",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (isCameraReady) EmeraldGreen else CrimsonRed
            )
        }

        // Camera Viewfinder Box with HUD crosshair overlay
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
                .testTag("camera_viewfinder"),
            color = DeepVoidSlate,
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            previewViewRef = this
                            viewModel.core.eyes.bindCamera(
                                lifecycleOwner = lifecycleOwner,
                                previewView = this,
                                onAutonomousVisionFrame = { bitmap ->
                                    viewModel.core.handleAutonomousVisionFrame(bitmap)
                                },
                                scope = viewModel.viewModelScope
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Visual HUD Overlay Reticles
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "SENSOR: CAM2_BACK // 1080P",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ArcCyan.copy(alpha = 0.8f),
                        modifier = Modifier.align(Alignment.TopStart)
                    )
                    Text(
                        text = "RANGE: INF // EXPOSURE: AUTO",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ArcCyan.copy(alpha = 0.8f),
                        modifier = Modifier.align(Alignment.TopEnd)
                    )
                }
            }
        }

        // Rapid Inspection Directives
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { viewModel.triggerVisionInspection("What do you see in the surroundings?") },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                    .testTag("inspect_surroundings_button")
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = ArcCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Surroundings", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }

            Button(
                onClick = { viewModel.triggerVisionInspection("Help me find anything valuable, useful, or notable in this environment.") },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                    .testTag("find_objects_button")
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = ArcCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Find Objects", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }

            Button(
                onClick = { viewModel.triggerVisionInspection("Read any text, labels, serial numbers, or markings visible in this view.") },
                colors = ButtonDefaults.buttonColors(containerColor = SurfaceCard, contentColor = TextPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                    .testTag("read_text_button")
            ) {
                Icon(Icons.Default.DocumentScanner, contentDescription = null, tint = ArcCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Read Text", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }

        // Custom Visual Query
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = customVisualQuery,
                onValueChange = { customVisualQuery = it },
                placeholder = { Text("Ask about what JARVIS sees...", color = TextMuted, fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("visual_query_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ArcCyan,
                    unfocusedBorderColor = BorderSubtle,
                    focusedContainerColor = SurfaceCard,
                    unfocusedContainerColor = SurfaceCard,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
            Button(
                onClick = {
                    if (customVisualQuery.isNotBlank()) {
                        viewModel.triggerVisionInspection(customVisualQuery)
                        customVisualQuery = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ArcCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("visual_query_submit_button")
            ) {
                Text("ANALYZE", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }

        // Visual Reasoning Report
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                .testTag("vision_report_card"),
            color = SurfaceCard,
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "VISUAL ANALYSIS REPORT",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ArcCyan,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (agentMode == AgentMode.INSPECTING_VISION) "Processing optical data through multimodal neural network..."
                    else currentThought,
                    fontSize = 13.sp,
                    color = TextPrimary,
                    lineHeight = 19.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
