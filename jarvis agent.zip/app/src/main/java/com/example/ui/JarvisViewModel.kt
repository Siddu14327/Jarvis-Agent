package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.JarvisApp
import com.example.agent.brain.AgentLogEntry
import com.example.agent.brain.AgentMode
import com.example.agent.brain.CognitiveCore
import com.example.agent.hands.InstalledAppInfo
import com.example.agent.perception.ScreenStateReport
import com.example.agent.senses.DeviceTelemetry
import com.example.agent.senses.EarsState
import com.example.data.EpisodeEntity
import com.example.data.FileArtifactEntity
import com.example.data.PheromoneTrailEntity
import com.example.data.VoiceIdentityEntity
import com.example.agent.files.DecodedFileResult
import com.example.agent.files.FileInspector
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val core: CognitiveCore = (application as JarvisApp).cognitiveCore

    // Core States
    val agentMode: StateFlow<AgentMode> = core.agentMode
    val currentThought: StateFlow<String> = core.currentThought
    val agentLogs: StateFlow<List<AgentLogEntry>> = core.logs

    // Senses
    val deviceTelemetry: StateFlow<DeviceTelemetry> = core.sensors.telemetry
    val earsState: StateFlow<EarsState> = core.ears.state
    val earsRms: StateFlow<Float> = core.ears.rmsLevel
    val partialSpeech: StateFlow<String> = core.ears.partialText
    val isSpeaking: StateFlow<Boolean> = core.voice.isSpeaking
    val lastSpoken: StateFlow<String> = core.voice.lastSpoken

    // Hands & Screen
    val isAccessibilityConnected: StateFlow<Boolean> = core.bridge.isConnected
    val activePackage: StateFlow<String> = core.bridge.activePackage
    val activeWindowTitle: StateFlow<String> = core.bridge.activeWindowTitle

    private val _screenReport = MutableStateFlow<ScreenStateReport?>(null)
    val screenReport: StateFlow<ScreenStateReport?> = _screenReport.asStateFlow()

    // Vision
    val isCameraReady: StateFlow<Boolean> = core.eyes.isCameraReady

    // Autonomous Consciousness
    val autonomousBodyMode: StateFlow<Boolean> = core.autonomousConsciousnessActive.asStateFlow()

    fun toggleAutonomousBodyMode() {
        val current = core.autonomousConsciousnessActive.value
        val newState = !current
        core.autonomousConsciousnessActive.value = newState
        core.eyes.toggleAutonomousScanning(newState)
        if (newState) {
            core.ears.startListening()
            core.voice.speak("Autonomous body mode engaged. I am listening and observing.")
        } else {
            core.ears.stopListening()
            core.voice.speak("Autonomous mode paused.")
        }
    }

    // Memory (Room)
    val recentEpisodes: StateFlow<List<EpisodeEntity>> = core.repository.recentEpisodes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pheromoneTrails: StateFlow<List<PheromoneTrailEntity>> = core.antBeeEngine.activeTrails
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val voiceProfile: StateFlow<VoiceIdentityEntity?> = core.voiceIdentity.currentProfile

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    // Files & Attachments
    val activeFile: StateFlow<DecodedFileResult?> = core.activeFile
    val fileArtifacts: StateFlow<List<FileArtifactEntity>> = core.repository.fileArtifacts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val isPlayingAudio: StateFlow<Boolean> = core.audioPlayer.isPlaying
    val currentlyPlayingAudioTitle: StateFlow<String?> = core.audioPlayer.currentlyPlayingTitle

    fun attachFile(uri: Uri) {
        viewModelScope.launch {
            core.attachAndDecodeFile(uri)
        }
    }

    fun clearActiveFile() {
        core.clearActiveFile()
    }

    fun toggleAudioPlayback(uri: Uri, title: String) {
        core.audioPlayer.loadAndPlay(uri, title)
    }

    fun openFileExternally(uri: Uri, mimeType: String) {
        FileInspector.openFileExternally(getApplication(), uri, mimeType)
    }

    init {
        refreshScreenReport()
        loadInstalledApps()
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _installedApps.value = core.navigator.getInstalledApps()
        }
    }

    fun refreshScreenReport() {
        viewModelScope.launch {
            _screenReport.value = core.perception.analyzeCurrentScreen()
        }
    }

    fun toggleListening() {
        if (earsState.value is EarsState.Listening) {
            core.ears.stopListening()
        } else {
            core.ears.startListening()
        }
    }

    fun submitTextCommand(command: String) {
        if (command.isNotBlank()) {
            core.processCommand(command, origin = "TEXT_PROMPT")
        }
    }

    fun triggerVisionInspection(query: String = "What do you see in the surroundings?") {
        core.inspectCameraSurroundings(query)
    }

    fun enrollVoiceProfile(name: String) {
        viewModelScope.launch {
            core.voiceIdentity.enrollVoice(name, sampleEnergy = 0.5f, samplePitchHz = 130.0f)
            core.voice.speak("Voice identity calibrated and recorded for $name.")
        }
    }

    fun performSystemAction(actionType: String, parameter: String = "") {
        viewModelScope.launch {
            when (actionType) {
                "BACK" -> core.bridge.performBack()
                "HOME" -> core.bridge.performHome()
                "NOTIFICATIONS" -> core.bridge.performNotifications()
                "SCROLL" -> core.bridge.scrollForward()
                "LAUNCH_MAPS" -> core.navigator.launchGoogleMaps(parameter.ifBlank { null })
                "LAUNCH_YOUTUBE" -> core.navigator.launchYouTube(parameter.ifBlank { null })
                "LAUNCH_BROWSER" -> core.navigator.launchWebBrowser(parameter.ifBlank { "https://google.com" })
                "LAUNCH_CAMERA" -> core.navigator.launchCamera()
                "LAUNCH_CALCULATOR" -> core.navigator.launchCalculator()
                "LAUNCH_DIALER" -> core.navigator.launchPhoneDialer(parameter.ifBlank { null })
                "LAUNCH_SETTINGS" -> core.navigator.launchSettings(parameter.ifBlank { "main" })
                "LAUNCH_APP" -> core.navigator.launchAppByNameOrPackage(parameter)
                "CLICK_TEXT" -> core.bridge.clickElementByTextOrDescription(parameter)
            }
            refreshScreenReport()
        }
    }
}
