package com.example.agent.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.JarvisApp
import com.example.agent.service.JarvisForegroundService

class JarvisBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val app = context.applicationContext as? JarvisApp

        when (action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                JarvisForegroundService.startService(context)
                app?.cognitiveCore?.log("BODY", "Device reboot detected. JARVIS agent consciousness restored.")
            }
            Intent.ACTION_POWER_CONNECTED -> {
                app?.cognitiveCore?.apply {
                    log("BODY", "External power supply engaged. Recharging body battery.")
                    sensors.updateTelemetry()
                    voice.speak("Power connected, sir. Recharging battery.")
                }
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                app?.cognitiveCore?.apply {
                    log("BODY", "External power disconnected. Switching to internal battery cell.")
                    sensors.updateTelemetry()
                }
            }
            Intent.ACTION_BATTERY_LOW -> {
                app?.cognitiveCore?.apply {
                    log("BODY", "Battery level critical! Conserving sensory bandwidth.")
                    sensors.updateTelemetry()
                    voice.speak("Warning: Main battery is running low.")
                }
            }
        }
    }
}
