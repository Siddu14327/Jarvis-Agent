package com.example.agent.accessibility

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.example.agent.hands.AccessibilityBridge

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("JarvisAccessibility", "JARVIS Accessibility Service bound. Neural screen interface active.")
        AccessibilityBridge.instance.bindService(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        val className = event.className?.toString() ?: ""

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                AccessibilityBridge.instance.updateActiveWindow(pkg, className)
            }
        }
    }

    override fun onInterrupt() {
        Log.w("JarvisAccessibility", "Accessibility service interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        AccessibilityBridge.instance.unbindService()
        Log.i("JarvisAccessibility", "JARVIS Accessibility Service destroyed.")
    }
}
