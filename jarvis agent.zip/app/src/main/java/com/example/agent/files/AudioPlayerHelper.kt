package com.example.agent.files

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioPlayerHelper(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var currentLoadedUri: Uri? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentlyPlayingTitle = MutableStateFlow<String?>(null)
    val currentlyPlayingTitle: StateFlow<String?> = _currentlyPlayingTitle.asStateFlow()

    fun loadAndPlay(uri: Uri, title: String) {
        try {
            if (currentLoadedUri == uri && mediaPlayer != null) {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.pause()
                    _isPlaying.value = false
                } else {
                    mediaPlayer?.start()
                    _isPlaying.value = true
                }
                return
            }

            stop()
            currentLoadedUri = uri
            _currentlyPlayingTitle.value = title

            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, uri)
                prepare()
                start()
                _isPlaying.value = true

                setOnCompletionListener {
                    _isPlaying.value = false
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPlayerHelper", "MediaPlayer error: what=$what extra=$extra")
                    _isPlaying.value = false
                    true
                }
            }
        } catch (e: Exception) {
            Log.e("AudioPlayerHelper", "Failed to play audio: ${e.message}")
            _isPlaying.value = false
        }
    }

    fun stop() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            _isPlaying.value = false
            currentLoadedUri = null
        } catch (e: Exception) {
            Log.w("AudioPlayerHelper", "Stop error: ${e.message}")
        }
    }

    fun release() {
        stop()
    }
}
