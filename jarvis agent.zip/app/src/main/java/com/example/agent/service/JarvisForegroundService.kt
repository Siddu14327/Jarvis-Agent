package com.example.agent.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.JarvisApp
import com.example.MainActivity
import com.example.R

class JarvisForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "jarvis_neural_core_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.jarvis.ACTION_START"
        const val ACTION_STOP = "com.example.jarvis.ACTION_STOP"
        const val ACTION_LISTEN = "com.example.jarvis.ACTION_LISTEN"
        const val ACTION_SPEAK_STATUS = "com.example.jarvis.ACTION_SPEAK_STATUS"
        const val ACTION_SCAN_SCREEN = "com.example.jarvis.ACTION_SCAN_SCREEN"

        fun startService(context: Context) {
            val intent = Intent(context, JarvisForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, JarvisForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> {
                val app = application as? JarvisApp
                app?.cognitiveCore?.let { core ->
                    core.voice.speak("Listening, sir.")
                    core.ears.startListening()
                }
            }
            ACTION_SPEAK_STATUS -> {
                val app = application as? JarvisApp
                app?.cognitiveCore?.let { core ->
                    val status = core.sensors.getSummaryString()
                    core.voice.speak(status)
                }
            }
            ACTION_SCAN_SCREEN -> {
                val app = application as? JarvisApp
                app?.cognitiveCore?.let { core ->
                    val report = core.perception.analyzeCurrentScreen()
                    core.voice.speak(report.summary)
                }
            }
        }

        val notification = buildAgentNotification("JARVIS Consciousness Active", "Ready for commands across Android")
        startForeground(NOTIFICATION_ID, notification)

        return START_STICKY
    }

    private fun buildAgentNotification(title: String, text: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Action: Listen
        val listenIntent = Intent(this, JarvisForegroundService::class.java).apply {
            action = ACTION_LISTEN
        }
        val listenPendingIntent = PendingIntent.getService(
            this,
            1,
            listenIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Action: Status
        val statusIntent = Intent(this, JarvisForegroundService::class.java).apply {
            action = ACTION_SPEAK_STATUS
        }
        val statusPendingIntent = PendingIntent.getService(
            this,
            2,
            statusIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Action: Scan Screen
        val scanIntent = Intent(this, JarvisForegroundService::class.java).apply {
            action = ACTION_SCAN_SCREEN
        }
        val scanPendingIntent = PendingIntent.getService(
            this,
            3,
            scanIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(android.R.drawable.ic_btn_speak_now, "Listen", listenPendingIntent)
            .addAction(android.R.drawable.ic_menu_search, "Scan Screen", scanPendingIntent)
            .addAction(android.R.drawable.ic_menu_info_details, "Status", statusPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.jarvis_service_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.jarvis_service_channel_desc)
                setShowBadge(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
