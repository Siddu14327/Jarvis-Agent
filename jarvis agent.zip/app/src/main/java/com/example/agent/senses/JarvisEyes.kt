package com.example.agent.senses

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.util.Base64
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import kotlin.coroutines.resume

data class VisionPerception(
    val summary: String,
    val identifiedObjects: List<String>,
    val spatialLocations: List<String>,
    val extractedText: String?,
    val timestamp: Long = System.currentTimeMillis()
)

class JarvisEyes(private val context: Context) {

    private var imageCapture: ImageCapture? = null
    private var autonomousScanJob: Job? = null

    private val _isCameraReady = MutableStateFlow(false)
    val isCameraReady: StateFlow<Boolean> = _isCameraReady.asStateFlow()

    private val _latestPerception = MutableStateFlow<VisionPerception?>(null)
    val latestPerception: StateFlow<VisionPerception?> = _latestPerception.asStateFlow()

    private val _isAutonomousScanning = MutableStateFlow(true)
    val isAutonomousScanning: StateFlow<Boolean> = _isAutonomousScanning.asStateFlow()

    fun bindCamera(
        lifecycleOwner: LifecycleOwner,
        previewView: androidx.camera.view.PreviewView? = null,
        onAutonomousVisionFrame: (suspend (Bitmap) -> Unit)? = null,
        scope: CoroutineScope? = null
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val preview = androidx.camera.core.Preview.Builder().build().also {
                    if (previewView != null) {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                }

                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageCapture)
                _isCameraReady.value = true

                // Start autonomous optic awareness loop
                if (scope != null && onAutonomousVisionFrame != null) {
                    startAutonomousOpticLoop(scope, onAutonomousVisionFrame)
                }
            } catch (e: Exception) {
                Log.e("JarvisEyes", "Failed to bind camera: ${e.message}")
                _isCameraReady.value = false
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun startAutonomousOpticLoop(
        scope: CoroutineScope,
        onAutonomousVisionFrame: suspend (Bitmap) -> Unit
    ) {
        autonomousScanJob?.cancel()
        autonomousScanJob = scope.launch(Dispatchers.Default) {
            delay(3000) // Initial delay after camera init
            while (isActive) {
                if (_isCameraReady.value && _isAutonomousScanning.value) {
                    try {
                        val bitmap = captureFrameBitmap()
                        if (bitmap != null) {
                            onAutonomousVisionFrame(bitmap)
                        }
                    } catch (e: Exception) {
                        Log.w("JarvisEyes", "Autonomous optic scan cycle: ${e.message}")
                    }
                }
                delay(9000) // Autonomous perception interval
            }
        }
    }

    suspend fun captureFrameBitmap(): Bitmap? = suspendCancellableCoroutine { continuation ->
        val capture = imageCapture
        if (capture == null) {
            continuation.resume(null)
            return@suspendCancellableCoroutine
        }

        try {
            capture.takePicture(
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        val bitmap = imageProxyToBitmap(image)
                        image.close()
                        continuation.resume(bitmap)
                    }

                    override fun onError(exception: ImageCaptureException) {
                        Log.e("JarvisEyes", "Frame capture error: ${exception.message}")
                        continuation.resume(null)
                    }
                }
            )
        } catch (e: Exception) {
            Log.e("JarvisEyes", "takePicture exception: ${e.message}")
            continuation.resume(null)
        }
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val planeProxy = image.planes[0]
        val buffer: ByteBuffer = planeProxy.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        val rotationDegrees = image.imageInfo.rotationDegrees
        return if (rotationDegrees != 0 && bitmap != null) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap ?: Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888)
        }
    }

    fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        val scaled = if (bitmap.width > 1024 || bitmap.height > 1024) {
            val ratio = 1024f / maxOf(bitmap.width, bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
        } else {
            bitmap
        }
        scaled.compress(Bitmap.CompressFormat.JPEG, 75, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    fun updatePerception(perception: VisionPerception) {
        _latestPerception.value = perception
    }

    fun toggleAutonomousScanning(enabled: Boolean) {
        _isAutonomousScanning.value = enabled
    }

    fun unbind() {
        autonomousScanJob?.cancel()
        autonomousScanJob = null
        _isCameraReady.value = false
    }
}
