package com.example.agent.hands

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log

data class InstalledAppInfo(
    val name: String,
    val packageName: String
)

class AppNavigator(private val context: Context) {

    fun launchGoogleMaps(query: String? = null): Boolean {
        return try {
            val uri = if (query.isNullOrBlank()) {
                Uri.parse("geo:0,0?q=")
            } else {
                Uri.parse("geo:0,0?q=" + Uri.encode(query))
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                true
            } else {
                // Fallback to generic map view or browser
                val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
                true
            }
        } catch (e: Exception) {
            Log.e("AppNavigator", "Failed to launch Maps: ${e.message}")
            false
        }
    }

    fun launchWebBrowser(urlOrQuery: String): Boolean {
        return try {
            val uri = if (urlOrQuery.startsWith("http://") || urlOrQuery.startsWith("https://")) {
                Uri.parse(urlOrQuery)
            } else {
                Uri.parse("https://www.google.com/search?q=" + Uri.encode(urlOrQuery))
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("AppNavigator", "Failed to launch browser: ${e.message}")
            false
        }
    }

    fun launchYouTube(searchQuery: String? = null): Boolean {
        return try {
            val intent = if (!searchQuery.isNullOrBlank()) {
                Intent(Intent.ACTION_SEARCH).apply {
                    setPackage("com.google.android.youtube")
                    putExtra("query", searchQuery)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }
            if (intent != null) {
                context.startActivity(intent)
                true
            } else {
                launchWebBrowser("https://www.youtube.com/results?search_query=" + Uri.encode(searchQuery ?: ""))
            }
        } catch (e: Exception) {
            Log.e("AppNavigator", "Failed to launch YouTube: ${e.message}")
            false
        }
    }

    fun launchPhoneDialer(number: String? = null): Boolean {
        return try {
            val uri = if (!number.isNullOrBlank()) Uri.parse("tel:$number") else Uri.parse("tel:")
            val intent = Intent(Intent.ACTION_DIAL, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("AppNavigator", "Failed to launch dialer: ${e.message}")
            false
        }
    }

    fun launchCamera(): Boolean {
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("AppNavigator", "Failed to launch camera: ${e.message}")
            false
        }
    }

    fun launchCalculator(): Boolean {
        val calcPackages = listOf(
            "com.google.android.calculator",
            "com.android.calculator2",
            "com.sec.android.app.popupcalculator",
            "com.miui.calculator"
        )
        for (pkg in calcPackages) {
            try {
                val intent = context.packageManager.getLaunchIntentForPackage(pkg)?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (intent != null) {
                    context.startActivity(intent)
                    return true
                }
            } catch (_: Exception) {}
        }
        return false
    }

    fun launchSettings(type: String = "main"): Boolean {
        return try {
            val action = when (type.lowercase()) {
                "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("AppNavigator", "Failed to launch settings: ${e.message}")
            false
        }
    }

    fun launchAppByNameOrPackage(target: String): Boolean {
        val pm = context.packageManager
        // Check if package directly
        pm.getLaunchIntentForPackage(target)?.let {
            it.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(it)
            return true
        }

        // Search matching app name in installed launcher apps
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        for (app in apps) {
            val label = app.loadLabel(pm).toString()
            if (label.contains(target, ignoreCase = true) || app.activityInfo.packageName.contains(target, ignoreCase = true)) {
                val launchIntent = pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (launchIntent != null) {
                    context.startActivity(launchIntent)
                    return true
                }
            }
        }
        return false
    }

    fun getInstalledApps(): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(mainIntent, 0)
        return resolved.map {
            InstalledAppInfo(
                name = it.loadLabel(pm).toString(),
                packageName = it.activityInfo.packageName
            )
        }.distinctBy { it.packageName }.sortedBy { it.name }
    }
}
