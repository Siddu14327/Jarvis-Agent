package com.example.agent.service

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.example.JarvisApp

@RequiresApi(Build.VERSION_CODES.N)
class JarvisQuickTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.let {
            it.state = Tile.STATE_ACTIVE
            it.label = "JARVIS"
            it.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val app = application as? JarvisApp
        app?.cognitiveCore?.let { core ->
            core.voice.speak("JARVIS at your command.")
            core.ears.startListening()
        }
        qsTile?.let {
            it.state = Tile.STATE_ACTIVE
            it.updateTile()
        }
    }
}
