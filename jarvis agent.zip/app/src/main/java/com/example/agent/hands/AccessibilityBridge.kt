package com.example.agent.hands

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UiElement(
    val id: String,
    val text: String,
    val contentDescription: String,
    val className: String,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val bounds: Rect,
    val nodeRef: AccessibilityNodeInfo? = null
)

class AccessibilityBridge {

    companion object {
        val instance = AccessibilityBridge()
    }

    private var activeService: AccessibilityService? = null

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _activePackage = MutableStateFlow("android")
    val activePackage: StateFlow<String> = _activePackage.asStateFlow()

    private val _activeWindowTitle = MutableStateFlow("Home")
    val activeWindowTitle: StateFlow<String> = _activeWindowTitle.asStateFlow()

    private val _visibleElements = MutableStateFlow<List<UiElement>>(emptyList())
    val visibleElements: StateFlow<List<UiElement>> = _visibleElements.asStateFlow()

    fun bindService(service: AccessibilityService) {
        activeService = service
        _isConnected.value = true
        refreshScreenState()
    }

    fun unbindService() {
        activeService = null
        _isConnected.value = false
    }

    fun updateActiveWindow(packageName: String, title: String) {
        _activePackage.value = packageName
        _activeWindowTitle.value = title
        refreshScreenState()
    }

    fun refreshScreenState() {
        val root = activeService?.rootInActiveWindow ?: return
        val elements = mutableListOf<UiElement>()
        collectNodes(root, elements)
        _visibleElements.value = elements
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, list: MutableList<UiElement>) {
        if (node == null) return
        if (node.isVisibleToUser) {
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val viewId = node.viewIdResourceName ?: ""
            val isClickable = node.isClickable
            val isEditable = node.isEditable
            val isScrollable = node.isScrollable

            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            if (text.isNotBlank() || desc.isNotBlank() || isClickable || isEditable || isScrollable) {
                list.add(
                    UiElement(
                        id = viewId,
                        text = text,
                        contentDescription = desc,
                        className = node.className?.toString() ?: "",
                        isClickable = isClickable,
                        isEditable = isEditable,
                        isScrollable = isScrollable,
                        bounds = bounds,
                        nodeRef = node
                    )
                )
            }
        }

        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), list)
        }
    }

    fun clickElementByTextOrDescription(query: String): Boolean {
        refreshScreenState()
        val match = _visibleElements.value.firstOrNull { elem ->
            elem.text.contains(query, ignoreCase = true) ||
                    elem.contentDescription.contains(query, ignoreCase = true)
        } ?: return false

        val node = match.nodeRef ?: return false
        return if (node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } else {
            // Parent might be clickable
            var parent = node.parent
            var clicked = false
            while (parent != null && !clicked) {
                if (parent.isClickable) {
                    clicked = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                parent = parent.parent
            }
            if (!clicked) {
                // Fallback to tap gesture at center bounds
                tapCoordinates(match.bounds.centerX().toFloat(), match.bounds.centerY().toFloat())
            }
            true
        }
    }

    fun typeTextIntoFocusedOrFirstEditable(text: String): Boolean {
        refreshScreenState()
        val editable = _visibleElements.value.firstOrNull { it.isEditable } ?: return false
        val node = editable.nodeRef ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollForward(): Boolean {
        refreshScreenState()
        val scrollable = _visibleElements.value.firstOrNull { it.isScrollable }
        return scrollable?.nodeRef?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    }

    fun performBack(): Boolean {
        return activeService?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
    }

    fun performHome(): Boolean {
        return activeService?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
    }

    fun performNotifications(): Boolean {
        return activeService?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: false
    }

    fun tapCoordinates(x: Float, y: Float, onComplete: ((Boolean) -> Unit)? = null): Boolean {
        val service = activeService ?: return false
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete?.invoke(false)
            }
        }, null)
    }
}
