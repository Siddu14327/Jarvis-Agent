package com.example.agent.perception

import com.example.agent.hands.AccessibilityBridge
import com.example.agent.hands.UiElement

data class ScreenStateReport(
    val activePackage: String,
    val appDisplayName: String,
    val screenTitle: String,
    val summary: String,
    val keyTexts: List<String>,
    val actionableButtons: List<String>,
    val hasInputField: Boolean,
    val inputHint: String?,
    val elementCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)

class ScreenPerceptionEngine(private val bridge: AccessibilityBridge) {

    fun analyzeCurrentScreen(): ScreenStateReport {
        bridge.refreshScreenState()
        val elements = bridge.visibleElements.value
        val pkg = bridge.activePackage.value
        val windowTitle = bridge.activeWindowTitle.value

        val appName = resolveAppDisplayName(pkg)
        val texts = elements.map { it.text.trim() }.filter { it.isNotBlank() }.distinct().take(15)
        val buttons = elements.filter { it.isClickable && (it.text.isNotBlank() || it.contentDescription.isNotBlank()) }
            .map { it.text.ifBlank { it.contentDescription } }
            .distinct()
            .take(8)

        val editables = elements.filter { it.isEditable }
        val hasInput = editables.isNotEmpty()
        val inputHint = editables.firstOrNull()?.let { it.text.ifBlank { it.contentDescription } }

        val summary = when {
            pkg.contains("maps") -> "Google Maps navigation & places screen ($appName). Visible options: ${buttons.joinToString(", ")}"
            pkg.contains("chrome") || pkg.contains("browser") -> "Web Browser active. Viewing content with ${texts.size} text sections."
            pkg.contains("youtube") -> "YouTube media player/feed active."
            pkg.contains("settings") -> "Android System Settings: $windowTitle."
            pkg.contains("dialer") || pkg.contains("telecom") -> "Phone dialer interface ready for communication."
            pkg.contains("camera") -> "System Camera viewfinder active."
            elements.isEmpty() -> "Screen idle or inaccessible window ($pkg)."
            else -> "Active interface: $appName. ${buttons.size} interactive controls, ${texts.size} readable elements."
        }

        return ScreenStateReport(
            activePackage = pkg,
            appDisplayName = appName,
            screenTitle = windowTitle,
            summary = summary,
            keyTexts = texts,
            actionableButtons = buttons,
            hasInputField = hasInput,
            inputHint = inputHint,
            elementCount = elements.size
        )
    }

    fun findBestTargetForIntent(intentPrompt: String): UiElement? {
        bridge.refreshScreenState()
        val elements = bridge.visibleElements.value
        val lowerPrompt = intentPrompt.lowercase()

        // 1. Exact or contains match on clickable text/description
        val directMatch = elements.firstOrNull { elem ->
            val t = elem.text.lowercase()
            val d = elem.contentDescription.lowercase()
            (t.isNotBlank() && lowerPrompt.contains(t)) ||
                    (d.isNotBlank() && lowerPrompt.contains(d)) ||
                    (t.isNotBlank() && t.contains(lowerPrompt))
        }
        if (directMatch != null) return directMatch

        // 2. Semantic keywords
        val keywords = when {
            lowerPrompt.contains("search") || lowerPrompt.contains("find") -> listOf("search", "find", "query", "explore", "magnifier", "lookup")
            lowerPrompt.contains("navigate") || lowerPrompt.contains("directions") -> listOf("directions", "start", "navigate", "route", "go")
            lowerPrompt.contains("petrol") || lowerPrompt.contains("gas") -> listOf("petrol", "gas", "fuel", "station")
            lowerPrompt.contains("next") || lowerPrompt.contains("continue") -> listOf("next", "continue", "forward", "submit", "done")
            lowerPrompt.contains("back") -> listOf("back", "up", "previous", "return")
            lowerPrompt.contains("close") || lowerPrompt.contains("cancel") -> listOf("close", "cancel", "dismiss", "exit")
            else -> emptyList()
        }

        for (kw in keywords) {
            val kwMatch = elements.firstOrNull { elem ->
                elem.text.contains(kw, ignoreCase = true) ||
                        elem.contentDescription.contains(kw, ignoreCase = true)
            }
            if (kwMatch != null) return kwMatch
        }

        // 3. Fallback to first editable if prompt indicates typing/searching
        if (lowerPrompt.contains("type") || lowerPrompt.contains("enter") || lowerPrompt.contains("search")) {
            elements.firstOrNull { it.isEditable }?.let { return it }
        }

        return null
    }

    fun verifyActionOutcome(previousReport: ScreenStateReport): Boolean {
        val current = analyzeCurrentScreen()
        // Check if package changed, or title changed, or element contents changed
        return current.activePackage != previousReport.activePackage ||
                current.screenTitle != previousReport.screenTitle ||
                current.keyTexts != previousReport.keyTexts
    }

    private fun resolveAppDisplayName(pkg: String): String {
        return when {
            pkg.contains("maps") -> "Google Maps"
            pkg.contains("youtube") -> "YouTube"
            pkg.contains("chrome") -> "Chrome Browser"
            pkg.contains("browser") -> "Browser"
            pkg.contains("dialer") -> "Phone"
            pkg.contains("settings") -> "Settings"
            pkg.contains("calculator") -> "Calculator"
            pkg.contains("camera") -> "Camera"
            pkg.contains("launcher") -> "Android Home Launcher"
            pkg.contains("com.example") || pkg.contains("com.aistudio.jarvis") -> "JARVIS Core Interface"
            else -> pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        }
    }
}
