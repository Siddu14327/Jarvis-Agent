package com.example.agent.senses

import com.example.data.JarvisRepository
import com.example.data.VoiceIdentityEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

data class VoiceAuthResult(
    val isAuthorized: Boolean,
    val confidence: Float,
    val userProfileName: String,
    val reason: String
)

class VoiceIdentitySubsystem(private val repository: JarvisRepository) {

    private val _currentProfile = MutableStateFlow<VoiceIdentityEntity?>(null)
    val currentProfile: StateFlow<VoiceIdentityEntity?> = _currentProfile.asStateFlow()

    suspend fun loadProfile() {
        val profile = repository.getVoiceProfileSync()
        _currentProfile.value = profile
    }

    suspend fun enrollVoice(name: String, sampleEnergy: Float, samplePitchHz: Float = 135.0f) {
        val profile = VoiceIdentityEntity(
            profileName = name,
            pitchFrequencyHz = samplePitchHz,
            energyVariance = sampleEnergy,
            confidenceThreshold = 0.65f,
            isEnrolled = true,
            updatedAt = System.currentTimeMillis()
        )
        repository.saveVoiceProfile(profile)
        _currentProfile.value = profile
    }

    suspend fun authenticateVoice(measuredEnergy: Float, measuredPitchHz: Float = 135.0f): VoiceAuthResult {
        val profile = _currentProfile.value ?: repository.getVoiceProfileSync()
        if (profile == null || !profile.isEnrolled) {
            // No profile enrolled yet: permissive open mode for primary user
            return VoiceAuthResult(
                isAuthorized = true,
                confidence = 0.85f,
                userProfileName = "Commander (Unenrolled)",
                reason = "Voice identity not strictly enrolled. Proceeding with standard authorization."
            )
        }

        // Calculate acoustic similarity
        val energyDelta = abs(profile.energyVariance - measuredEnergy)
        val pitchDelta = abs(profile.pitchFrequencyHz - measuredPitchHz) / profile.pitchFrequencyHz

        val energyScore = (1.0f - (energyDelta * 1.5f)).coerceIn(0.1f, 1.0f)
        val pitchScore = (1.0f - (pitchDelta * 2.0f)).coerceIn(0.1f, 1.0f)

        val combinedConfidence = (energyScore * 0.4f) + (pitchScore * 0.6f)
        val isMatch = combinedConfidence >= profile.confidenceThreshold

        return VoiceAuthResult(
            isAuthorized = isMatch,
            confidence = combinedConfidence,
            userProfileName = profile.profileName,
            reason = if (isMatch) "Voice print matches ${profile.profileName} (${(combinedConfidence * 100).toInt()}% match)"
            else "Voice signature deviates from ${profile.profileName} profile (${(combinedConfidence * 100).toInt()}% match vs ${(profile.confidenceThreshold * 100).toInt()}% required)"
        )
    }

    fun isActionSensitive(command: String): Boolean {
        val lower = command.lowercase()
        return lower.contains("delete") ||
                lower.contains("wipe") ||
                lower.contains("uninstall") ||
                lower.contains("format") ||
                lower.contains("factory reset") ||
                lower.contains("transfer money") ||
                lower.contains("lock device")
    }
}
