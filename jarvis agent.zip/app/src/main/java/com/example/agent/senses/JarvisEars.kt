package com.example.agent.senses

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed class EarsState {
    object Idle : EarsState()
    object Listening : EarsState()
    object Processing : EarsState()
    data class Error(val message: String) : EarsState()
}

class JarvisEars(
    private val context: Context,
    private val onSpeechRecognized: (String, Float) -> Unit
) {

    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow<EarsState>(EarsState.Idle)
    val state: StateFlow<EarsState> = _state.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    // Autonomous always-on listening mode
    private var isAutonomousListening = true
    private var isPausedByVoice = false

    private var lastAverageRms = 0f
    private var sampleCount = 0

    init {
        initializeRecognizer()
    }

    private fun initializeRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _state.value = EarsState.Error("Speech recognition not available on this device")
            return
        }

        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _state.value = EarsState.Listening
                            _partialText.value = ""
                            lastAverageRms = 0f
                            sampleCount = 0
                        }

                        override fun onBeginningOfSpeech() {
                            _state.value = EarsState.Listening
                        }

                        override fun onRmsChanged(rmsdB: Float) {
                            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                            _rmsLevel.value = normalized
                            lastAverageRms += normalized
                            sampleCount++
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _state.value = EarsState.Processing
                            _rmsLevel.value = 0f
                        }

                        override fun onError(error: Int) {
                            _rmsLevel.value = 0f
                            val isTransient = error == SpeechRecognizer.ERROR_NO_MATCH ||
                                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                                    error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                                    error == SpeechRecognizer.ERROR_CLIENT

                            if (isTransient) {
                                // In autonomous mode, auto-recover seamlessly
                                scheduleAutonomousRestart(delayMs = 400)
                            } else {
                                val msg = when (error) {
                                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Audio permission required"
                                    SpeechRecognizer.ERROR_NETWORK -> "Network required for speech"
                                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                                    else -> "Speech recognition error ($error)"
                                }
                                _state.value = EarsState.Error(msg)
                                scheduleAutonomousRestart(delayMs = 1200)
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            _rmsLevel.value = 0f
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull() ?: ""
                            _partialText.value = text
                            _state.value = EarsState.Idle

                            if (text.isNotBlank()) {
                                val avgEnergy = if (sampleCount > 0) (lastAverageRms / sampleCount) else 0.5f
                                onSpeechRecognized(text, avgEnergy)
                            }

                            // Autonomous loop: schedule immediate re-arm
                            scheduleAutonomousRestart(delayMs = 300)
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull() ?: ""
                            _partialText.value = text
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            } catch (e: Exception) {
                Log.e("JarvisEars", "Initialization error: ${e.message}")
            }
        }
    }

    private fun scheduleAutonomousRestart(delayMs: Long) {
        if (!isAutonomousListening || isPausedByVoice) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (isAutonomousListening && !isPausedByVoice) {
                startListeningInternal()
            }
        }, delayMs)
    }

    fun startListening() {
        isAutonomousListening = true
        isPausedByVoice = false
        startListeningInternal()
    }

    fun stopListening() {
        isAutonomousListening = false
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                _rmsLevel.value = 0f
                _state.value = EarsState.Idle
            } catch (e: Exception) {
                Log.w("JarvisEars", "Failed to stop listening: ${e.message}")
            }
        }
    }

    fun pauseListeningForSpeaking() {
        isPausedByVoice = true
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                _rmsLevel.value = 0f
                _state.value = EarsState.Idle
            } catch (_: Exception) {}
        }
    }

    fun resumeListeningAfterSpeaking() {
        isPausedByVoice = false
        if (isAutonomousListening) {
            scheduleAutonomousRestart(delayMs = 250)
        }
    }

    private fun startListeningInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return

        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("JarvisEars", "startListening error", e)
                _state.value = EarsState.Error(e.message ?: "Listening error")
                scheduleAutonomousRestart(delayMs = 1500)
            }
        }
    }

    fun destroy() {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (e: Exception) {
                Log.w("JarvisEars", "Failed to destroy speech recognizer", e)
            }
        }
    }
}
