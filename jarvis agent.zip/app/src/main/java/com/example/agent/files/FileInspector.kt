package com.example.agent.files

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipInputStream

enum class FileCategory {
    IMAGE,
    VIDEO,
    AUDIO,
    PDF,
    DOCUMENT,
    TEXT_CODE,
    ARCHIVE,
    BINARY
}

data class DecodedFileResult(
    val uri: Uri,
    val fileName: String,
    val mimeType: String,
    val fileSizeBytes: Long,
    val formattedSize: String,
    val category: FileCategory,
    val thumbnailBitmap: Bitmap? = null,
    val decodedSummary: String,
    val detailedTextContent: String? = null,
    val technicalMetadata: Map<String, String> = emptyMap(),
    val canPlayAudio: Boolean = false
)

object FileInspector {

    suspend fun inspectAndDecode(context: Context, uri: Uri): DecodedFileResult = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver

        // 1. Resolve Display Name & Size from ContentResolver or URI path
        var fileName = uri.lastPathSegment ?: "unknown_file"
        var fileSize = 0L

        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) cursor.getString(nameIndex)?.let { fileName = it }
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            Log.w("FileInspector", "Could not query OpenableColumns: ${e.message}")
        }

        // Direct file fallback
        if (fileSize <= 0L && uri.scheme == "file") {
            try {
                val path = uri.path
                if (path != null) {
                    val f = java.io.File(path)
                    if (f.exists()) {
                        fileSize = f.length()
                        if (fileName == "unknown_file" || fileName.isBlank()) fileName = f.name
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. Resolve Mime Type
        val resolvedMime = contentResolver.getType(uri) ?: resolveMimeFromExtension(fileName)
        val formattedSize = formatFileSize(fileSize)

        // 3. Categorize File
        val category = determineCategory(resolvedMime, fileName)

        // 4. Decode based on Category
        return@withContext when (category) {
            FileCategory.IMAGE -> decodeImage(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.PDF -> decodePdf(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.AUDIO -> decodeAudio(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.VIDEO -> decodeVideo(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.DOCUMENT -> decodeDocument(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.TEXT_CODE -> decodeText(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.ARCHIVE -> decodeArchive(context, uri, fileName, resolvedMime, fileSize, formattedSize)
            FileCategory.BINARY -> decodeBinary(context, uri, fileName, resolvedMime, fileSize, formattedSize)
        }
    }

    private fun determineCategory(mimeType: String, fileName: String): FileCategory {
        val lowerMime = mimeType.lowercase(Locale.ROOT)
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)

        return when {
            lowerMime.startsWith("image/") || ext in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "svg") -> FileCategory.IMAGE
            lowerMime.startsWith("video/") || ext in listOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "flv", "m4v") -> FileCategory.VIDEO
            lowerMime.startsWith("audio/") || ext in listOf("mp3", "wav", "m4a", "ogg", "flac", "aac", "opus", "mid", "midi", "wma") -> FileCategory.AUDIO
            lowerMime == "application/pdf" || ext == "pdf" -> FileCategory.PDF
            lowerMime.contains("wordprocessingml") || lowerMime.contains("spreadsheetml") || lowerMime.contains("presentationml") ||
                    ext in listOf("docx", "doc", "xlsx", "xls", "pptx", "ppt", "odt", "ods", "odp", "rtf", "epub") -> FileCategory.DOCUMENT
            lowerMime.startsWith("text/") || lowerMime.contains("json") || lowerMime.contains("xml") || lowerMime.contains("javascript") ||
                    ext in listOf("txt", "json", "xml", "kt", "java", "py", "c", "cpp", "h", "hpp", "js", "ts", "html", "css", "md", "csv", "log", "sh", "yaml", "yml", "toml", "sql", "conf", "gradle") -> FileCategory.TEXT_CODE
            lowerMime.contains("zip") || lowerMime.contains("tar") || lowerMime.contains("rar") || lowerMime.contains("gzip") ||
                    ext in listOf("zip", "rar", "tar", "gz", "7z", "apk", "aar", "jar") -> FileCategory.ARCHIVE
            else -> FileCategory.BINARY
        }
    }

    private fun decodeImage(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        var bitmap: Bitmap? = null
        var width = 0
        var height = 0
        val meta = mutableMapOf<String, String>()

        try {
            // First check dimensions
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
                width = boundsOptions.outWidth
                height = boundsOptions.outHeight
            }

            // Decode scaled bitmap
            val scale = calculateInSampleSize(boundsOptions, 1080, 1080)
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = scale
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                bitmap = BitmapFactory.decodeStream(stream, null, decodeOptions)
            }

            // Read EXIF metadata if supported format
            context.contentResolver.openInputStream(uri)?.use { stream ->
                try {
                    val exif = ExifInterface(stream)
                    val make = exif.getAttribute(ExifInterface.TAG_MAKE)
                    val model = exif.getAttribute(ExifInterface.TAG_MODEL)
                    val date = exif.getAttribute(ExifInterface.TAG_DATETIME)
                    val iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS)
                    val fNum = exif.getAttribute(ExifInterface.TAG_F_NUMBER)
                    val exposure = exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME)

                    if (!make.isNullOrBlank() || !model.isNullOrBlank()) {
                        meta["Camera"] = "${make ?: ""} ${model ?: ""}".trim()
                    }
                    if (!date.isNullOrBlank()) meta["Date Taken"] = date
                    if (!iso.isNullOrBlank()) meta["ISO"] = iso
                    if (!fNum.isNullOrBlank()) meta["Aperture"] = "f/$fNum"
                    if (!exposure.isNullOrBlank()) meta["Exposure"] = "${exposure}s"
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.e("FileInspector", "Error decoding image: ${e.message}")
        }

        meta["Resolution"] = "${width}x${height} px"
        meta["MIME Type"] = mime
        meta["File Size"] = formattedSize
        meta["Color Channels"] = "RGBA"

        val cameraTag = meta["Camera"]?.let { " captured via $it" } ?: ""
        val summary = "Visual Image Asset (${width}x${height} px, $formattedSize$cameraTag). Decoded for neural vision inspection."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.IMAGE,
            thumbnailBitmap = bitmap,
            decodedSummary = summary,
            technicalMetadata = meta
        )
    }

    private fun decodePdf(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        var pageCount = 0
        var renderedBitmap: Bitmap? = null

        try {
            val pfd: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(uri, "r")
            if (pfd != null) {
                PdfRenderer(pfd).use { renderer ->
                    pageCount = renderer.pageCount
                    if (pageCount > 0) {
                        renderer.openPage(0).use { page ->
                            val scale = (1080f / page.width.coerceAtLeast(1)).coerceIn(1f, 2.5f)
                            val targetWidth = (page.width * scale).toInt()
                            val targetHeight = (page.height * scale).toInt()
                            val bmp = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(android.graphics.Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            renderedBitmap = bmp
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("FileInspector", "PdfRenderer error: ${e.message}")
        }

        val meta = mapOf(
            "Page Count" to "$pageCount pages",
            "Document Type" to "Portable Document Format (PDF)",
            "Cover Page" to if (renderedBitmap != null) "Page 1 rendered" else "Render error",
            "File Size" to formattedSize
        )
        val summary = "PDF Document: $pageCount total pages ($formattedSize). Page 1 rendered into high-resolution neural buffer."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.PDF,
            thumbnailBitmap = renderedBitmap,
            decodedSummary = summary,
            technicalMetadata = meta
        )
    }

    private fun decodeAudio(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        var title: String? = null
        var artist: String? = null
        var album: String? = null
        var durationMs: Long = 0
        var bitrate: String? = null
        var genre: String? = null
        var year: String? = null
        var albumArt: Bitmap? = null

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            year = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durStr?.toLongOrNull() ?: 0L

            val artBytes = retriever.embeddedPicture
            if (artBytes != null) {
                albumArt = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size)
            }
        } catch (e: Exception) {
            Log.w("FileInspector", "MediaMetadataRetriever audio error: ${e.message}")
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }

        val formattedDuration = formatDuration(durationMs)
        val displayTitle = title ?: fileName.substringBeforeLast('.')
        val displayArtist = artist ?: "Unknown Artist"
        val bitrateKbps = bitrate?.toLongOrNull()?.let { "${it / 1000} kbps" } ?: "VBR"

        val meta = mutableMapOf(
            "Track Title" to displayTitle,
            "Artist" to displayArtist,
            "Duration" to formattedDuration,
            "Bitrate" to bitrateKbps,
            "File Size" to formattedSize
        )
        if (!album.isNullOrBlank()) meta["Album"] = album
        if (!genre.isNullOrBlank()) meta["Genre"] = genre
        if (!year.isNullOrBlank()) meta["Year"] = year

        val summary = "Audio Song: \"$displayTitle\" by $displayArtist (Duration: $formattedDuration, $bitrateKbps, $formattedSize)."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.AUDIO,
            thumbnailBitmap = albumArt,
            decodedSummary = summary,
            technicalMetadata = meta,
            canPlayAudio = true
        )
    }

    private fun decodeVideo(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        var width: String? = null
        var height: String? = null
        var durationMs = 0L
        var bitrate: String? = null
        var rotation: String? = null
        var keyFrameBitmap: Bitmap? = null

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durStr?.toLongOrNull() ?: 0L

            // Extract real video keyframe at 1.0 second
            keyFrameBitmap = retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            Log.w("FileInspector", "MediaMetadataRetriever video error: ${e.message}")
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }

        val formattedDuration = formatDuration(durationMs)
        val resolution = if (width != null && height != null) "${width}x${height}" else "HD Video"
        val bitrateMbps = bitrate?.toLongOrNull()?.let { "%.1f Mbps".format(it / 1000000.0) } ?: "Standard"

        val meta = mapOf(
            "Resolution" to resolution,
            "Duration" to formattedDuration,
            "Bitrate" to bitrateMbps,
            "Rotation" to (rotation?.let { "${it}°" } ?: "0°"),
            "Keyframe" to if (keyFrameBitmap != null) "Extracted" else "None",
            "File Size" to formattedSize
        )

        val summary = "Video Stream: $resolution resolution, duration $formattedDuration ($bitrateMbps, $formattedSize). Keyframe captured for visual comprehension."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.VIDEO,
            thumbnailBitmap = keyFrameBitmap,
            decodedSummary = summary,
            technicalMetadata = meta
        )
    }

    private fun decodeDocument(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val textBuilder = StringBuilder()
        var docFormat = "Office Document"
        var wordCount = 0
        var paragraphCount = 0

        try {
            if (ext == "docx" || mime.contains("wordprocessingml")) {
                docFormat = "Microsoft Word Document (.docx)"
                context.contentResolver.openInputStream(uri)?.use { rawStream ->
                    ZipInputStream(rawStream).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            if (entry.name == "word/document.xml") {
                                val content = readStreamToString(zis, maxBytes = 100000)
                                // Extract text between XML tags <w:t>...</w:t>
                                val regex = "<w:t[^>]*>(.*?)</w:t>".toRegex()
                                val matches = regex.findAll(content)
                                for (match in matches) {
                                    val text = match.groupValues[1]
                                    textBuilder.append(text).append(" ")
                                }
                                break
                            }
                            entry = zis.nextEntry
                        }
                    }
                }
            } else if (ext == "xlsx" || mime.contains("spreadsheetml")) {
                docFormat = "Microsoft Excel Spreadsheet (.xlsx)"
                context.contentResolver.openInputStream(uri)?.use { rawStream ->
                    ZipInputStream(rawStream).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            if (entry.name == "xl/sharedStrings.xml") {
                                val content = readStreamToString(zis, maxBytes = 80000)
                                val regex = "<t[^>]*>(.*?)</t>".toRegex()
                                val matches = regex.findAll(content)
                                for (match in matches) {
                                    textBuilder.append(match.groupValues[1]).append(" | ")
                                }
                                break
                            }
                            entry = zis.nextEntry
                        }
                    }
                }
            } else if (ext == "pptx" || mime.contains("presentationml")) {
                docFormat = "Microsoft PowerPoint Presentation (.pptx)"
                var slideCount = 0
                context.contentResolver.openInputStream(uri)?.use { rawStream ->
                    ZipInputStream(rawStream).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            if (entry.name.startsWith("ppt/slides/slide") && entry.name.endsWith(".xml")) {
                                slideCount++
                                val content = readStreamToString(zis, maxBytes = 20000)
                                val regex = "<a:t>(.*?)</a:t>".toRegex()
                                val slideTexts = regex.findAll(content).map { it.groupValues[1] }.joinToString(" ")
                                if (slideTexts.isNotBlank()) {
                                    textBuilder.append("[Slide $slideCount] ").append(slideTexts).append("\n")
                                }
                            }
                            entry = zis.nextEntry
                        }
                    }
                }
            } else {
                // Fallback for RTF / TXT-based documents
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                        var line = reader.readLine()
                        while (line != null && textBuilder.length < 50000) {
                            textBuilder.append(line).append("\n")
                            line = reader.readLine()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("FileInspector", "Document decoding error: ${e.message}")
        }

        val extracted = textBuilder.toString().trim()
        val words = extracted.split("\\s+".toRegex()).filter { it.isNotBlank() }
        wordCount = words.size
        paragraphCount = extracted.split("\n\n").filter { it.isNotBlank() }.size.coerceAtLeast(1)

        val meta = mapOf(
            "Format" to docFormat,
            "Words Extracted" to "$wordCount words",
            "Paragraphs/Sections" to "$paragraphCount sections",
            "File Size" to formattedSize
        )

        val summary = if (extracted.isNotBlank()) {
            "$docFormat: $wordCount words extracted from document body ($formattedSize)."
        } else {
            "$docFormat: Package verified ($formattedSize). Document structure cataloged."
        }

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.DOCUMENT,
            decodedSummary = summary,
            detailedTextContent = extracted.ifBlank { "Document binary structure cataloged. Ready to open in office viewer." },
            technicalMetadata = meta
        )
    }

    private fun decodeText(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        val stringBuilder = StringBuilder()
        var lineCount = 0
        var wordCount = 0
        val maxChars = 100000

        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                    var line = reader.readLine()
                    while (line != null && stringBuilder.length < maxChars) {
                        lineCount++
                        val words = line.split("\\s+".toRegex()).filter { it.isNotBlank() }
                        wordCount += words.size
                        stringBuilder.append(line).append("\n")
                        line = reader.readLine()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("FileInspector", "Error reading text file: ${e.message}")
        }

        val textContent = stringBuilder.toString()
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)

        val meta = mutableMapOf(
            "Lines" to "$lineCount lines",
            "Words" to "$wordCount words",
            "Characters" to "${textContent.length} chars",
            "Encoding" to "UTF-8",
            "File Size" to formattedSize
        )

        // Type-specific analysis
        if (ext == "csv") {
            val delimiter = if (textContent.contains(";")) ";" else ","
            val rows = textContent.lines().filter { it.isNotBlank() }
            val cols = rows.firstOrNull()?.split(delimiter)?.size ?: 0
            meta["CSV Table"] = "${rows.size} rows × $cols columns"
        } else if (ext == "json") {
            val isObject = textContent.trimStart().startsWith("{")
            val isArray = textContent.trimStart().startsWith("[")
            meta["JSON Type"] = if (isObject) "JSON Object" else if (isArray) "JSON Array" else "JSON Value"
        }

        val summary = "Text/Code File: $lineCount lines, $wordCount words ($formattedSize). Decoded structure into neural working memory."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.TEXT_CODE,
            detailedTextContent = textContent,
            decodedSummary = summary,
            technicalMetadata = meta
        )
    }

    private fun decodeArchive(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        val entriesList = mutableListOf<String>()
        var totalEntries = 0
        var totalUncompressedBytes = 0L

        try {
            context.contentResolver.openInputStream(uri)?.use { rawStream ->
                ZipInputStream(rawStream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        totalEntries++
                        if (entry.size > 0) totalUncompressedBytes += entry.size
                        if (entriesList.size < 60) {
                            val sizeStr = if (entry.size > 0) formatFileSize(entry.size) else if (entry.isDirectory) "DIR" else "FILE"
                            entriesList.add("${entry.name} ($sizeStr)")
                        }
                        entry = zis.nextEntry
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("FileInspector", "Archive inspection warning: ${e.message}")
        }

        val manifest = if (entriesList.isNotEmpty()) {
            val header = "ARCHIVE MANIFEST ($totalEntries total entries):\n"
            header + entriesList.joinToString("\n") + if (totalEntries > entriesList.size) "\n... and ${totalEntries - entriesList.size} more files" else ""
        } else {
            "Archive cataloged ($formattedSize). Standard package format."
        }

        val meta = mapOf(
            "Entries Count" to "$totalEntries items",
            "Uncompressed Size" to formatFileSize(totalUncompressedBytes),
            "Archive Format" to "ZIP / Container",
            "File Size" to formattedSize
        )

        val summary = "Archive Package: $totalEntries files cataloged (${formatFileSize(totalUncompressedBytes)} uncompressed, $formattedSize package). Ready for system package / extraction."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.ARCHIVE,
            decodedSummary = summary,
            detailedTextContent = manifest,
            technicalMetadata = meta
        )
    }

    private fun decodeBinary(
        context: Context,
        uri: Uri,
        fileName: String,
        mime: String,
        size: Long,
        formattedSize: String
    ): DecodedFileResult {
        val magicBytes = ByteArray(32)
        var sha256Checksum = "calculating..."

        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.read(magicBytes)
            }

            val md = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val buffer = ByteArray(8192)
                var read = stream.read(buffer)
                var total = 0
                while (read != -1 && total < 1048576) {
                    md.update(buffer, 0, read)
                    total += read
                    read = stream.read(buffer)
                }
            }
            sha256Checksum = md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            Log.w("FileInspector", "Binary inspect error: ${e.message}")
        }

        val magicIdentity = identifyMagicHeader(magicBytes)
        val hexDump = formatHexDump(magicBytes)

        val meta = mapOf(
            "Identity" to magicIdentity,
            "SHA-256 Digest" to sha256Checksum.take(16) + "...",
            "File Size" to formattedSize
        )

        val summary = "Binary Payload ($magicIdentity, $formattedSize, SHA-256: ${sha256Checksum.take(10)}...). Machine code / byte stream analyzed."

        return DecodedFileResult(
            uri = uri,
            fileName = fileName,
            mimeType = mime,
            fileSizeBytes = size,
            formattedSize = formattedSize,
            category = FileCategory.BINARY,
            decodedSummary = summary,
            detailedTextContent = "HEX DUMP (FIRST 32 BYTES):\n$hexDump\n\nSHA-256: $sha256Checksum",
            technicalMetadata = meta
        )
    }

    fun openFileExternally(context: Context, uri: Uri, mimeType: String): Boolean {
        return try {
            val effectiveMime = if (mimeType.isNotBlank() && mimeType != "*/*") mimeType else "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, effectiveMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Open file with...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            Log.e("FileInspector", "Failed to open file externally: ${e.message}")
            false
        }
    }

    private fun readStreamToString(input: InputStream, maxBytes: Int): String {
        val buffer = ByteArray(4096)
        val out = java.io.ByteArrayOutputStream()
        var read = input.read(buffer)
        var total = 0
        while (read != -1 && total < maxBytes) {
            out.write(buffer, 0, read)
            total += read
            read = input.read(buffer)
        }
        return out.toString("UTF-8")
    }

    private fun formatHexDump(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (i in bytes.indices step 16) {
            sb.append("%08X: ".format(i))
            val lineBytes = bytes.sliceArray(i until (i + 16).coerceAtMost(bytes.size))
            for (b in lineBytes) {
                sb.append("%02X ".format(b))
            }
            sb.append(" |")
            for (b in lineBytes) {
                val c = b.toInt().toChar()
                sb.append(if (c in ' '..'~') c else '.')
            }
            sb.append("|\n")
        }
        return sb.toString().trimEnd()
    }

    private fun identifyMagicHeader(bytes: ByteArray): String {
        if (bytes.size < 4) return "Generic Binary Stream"
        return when {
            bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte() && bytes[2] == 0x03.toByte() -> "ZIP / Office / APK Container (PK..)"
            bytes[0] == 0x25.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x44.toByte() && bytes[3] == 0x46.toByte() -> "PDF Document (%PDF)"
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "PNG Image"
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "JPEG Image"
            bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() && bytes[2] == 0x46.toByte() -> "GIF Image"
            bytes[0] == 0x1F.toByte() && bytes[1] == 0x8B.toByte() -> "GZIP Compressed File"
            bytes[0] == 0x52.toByte() && bytes[1] == 0x61.toByte() && bytes[2] == 0x72.toByte() -> "RAR Archive"
            bytes[0] == 0x7F.toByte() && bytes[1] == 0x45.toByte() && bytes[2] == 0x4C.toByte() && bytes[3] == 0x46.toByte() -> "ELF Linux/Android Executable"
            bytes[0] == 0x53.toByte() && bytes[1] == 0x51.toByte() && bytes[2] == 0x4C.toByte() -> "SQLite 3 Database"
            bytes[0] == 0x64.toByte() && bytes[1] == 0x65.toByte() && bytes[2] == 0x78.toByte() -> "Android DEX Bytecode"
            else -> "Generic Binary Stream"
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var digitGroups = 0
        var b = bytes.toDouble()
        while (b >= 1024 && digitGroups < units.size - 1) {
            b /= 1024
            digitGroups++
        }
        return "%.1f %s".format(b, units[digitGroups])
    }

    private fun formatDuration(ms: Long): String {
        val totalSecs = ms / 1000
        val hours = totalSecs / 3600
        val minutes = (totalSecs % 3600) / 60
        val seconds = totalSecs % 60
        return if (hours > 0) {
            "%02d:%02d:%02d".format(hours, minutes, seconds)
        } else {
            "%02d:%02d".format(minutes, seconds)
        }
    }

    private fun resolveMimeFromExtension(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "m4a" -> "audio/mp4"
            "pdf" -> "application/pdf"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            "txt" -> "text/plain"
            "json" -> "application/json"
            "xml" -> "text/xml"
            "zip" -> "application/zip"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }
}
