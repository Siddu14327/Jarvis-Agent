package com.example.agent.brain

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiReasoningEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun reasonAboutTask(
        systemPrompt: String,
        userIntent: String,
        screenContext: String,
        telemetryContext: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext fallbackHeuristicReasoning(userIntent, screenContext)
        }

        val prompt = buildString {
            append("SYSTEM INSTRUCTION: You are JARVIS, an autonomous personal digital agent operating an Android phone as your physical body.\n")
            append(systemPrompt).append("\n\n")
            append("CURRENT PHONE BODY TELEMETRY:\n").append(telemetryContext).append("\n\n")
            append("CURRENT SCREEN PERCEPTION:\n").append(screenContext).append("\n\n")
            append("USER INSTRUCTION: ").append(userIntent).append("\n\n")
            append("Provide your concise operational decision, plan of action across Android, and what to speak back to the user.")
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val err = response.body?.string() ?: "HTTP ${response.code}"
                    Log.w("GeminiReasoning", "API failed ($err), using heuristic fallback.")
                    return@withContext fallbackHeuristicReasoning(userIntent, screenContext)
                }
                val respStr = response.body?.string() ?: ""
                val respJson = JSONObject(respStr)
                val candidates = respJson.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val text = parts?.optJSONObject(0)?.optString("text", "") ?: ""
                if (text.isNotBlank()) text else fallbackHeuristicReasoning(userIntent, screenContext)
            }
        } catch (e: Exception) {
            Log.e("GeminiReasoning", "Reasoning call error: ${e.message}")
            fallbackHeuristicReasoning(userIntent, screenContext)
        }
    }

    suspend fun analyzeVision(
        imageBase64: String,
        userQuery: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Camera vision active. Identified primary object in view. Spatial orientation: centered. Awaiting Gemini API key for neural semantic inspection."
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "You are JARVIS's visual cortex. Inspect this camera frame carefully. User says: '$userQuery'. Identify objects, note their spatial locations (e.g. lower-left, upper-right), read any visible text/markings, and report clearly as JARVIS.")
                            })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", imageBase64)
                                })
                            })
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext "Visual cortex encountered an optical telemetry delay (${response.code})."
                }
                val respStr = response.body?.string() ?: ""
                val respJson = JSONObject(respStr)
                val text = respJson.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text", "") ?: ""
                if (text.isNotBlank()) text else "Visual analysis completed. No distinct anomalies detected."
            }
        } catch (e: Exception) {
            "Visual processing error: ${e.message}"
        }
    }

    private fun fallbackHeuristicReasoning(userIntent: String, screenContext: String): String {
        val lower = userIntent.lowercase()
        return when {
            lower.contains("map") || lower.contains("petrol") || lower.contains("gas") || lower.contains("navigate") ->
                "Understood, sir. Initiating navigation matrix via Google Maps to fulfill destination directives."
            lower.contains("youtube") || lower.contains("video") || lower.contains("play") ->
                "Accessing media feed through YouTube as requested."
            lower.contains("search") || lower.contains("browser") || lower.contains("web") ->
                "Opening web interface to retrieve the requested intelligence."
            lower.contains("camera") || lower.contains("see") || lower.contains("look") ->
                "Aligning optical sensors. Engaging real-time visual inspection."
            lower.contains("battery") || lower.contains("status") || lower.contains("diagnostic") ->
                "Diagnostics nominal. Power systems and device sensors operating at peak integrity."
            lower.contains("call") || lower.contains("phone") || lower.contains("dial") ->
                "Opening communications transceiver to initialize dialer protocol."
            else ->
                "Directive received: '$userIntent'. Evaluating screen elements and executing appropriate tactical response through Android system controls."
        }
    }
}
