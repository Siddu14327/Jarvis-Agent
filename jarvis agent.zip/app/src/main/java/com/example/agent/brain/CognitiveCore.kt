package com.example.agent.brain

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.agent.files.AudioPlayerHelper
import com.example.agent.files.DecodedFileResult
import com.example.agent.files.FileCategory
import com.example.agent.files.FileInspector
import com.example.agent.hands.AccessibilityBridge
import com.example.agent.hands.AppNavigator
import com.example.agent.perception.ScreenPerceptionEngine
import com.example.agent.senses.DeviceSensors
import com.example.agent.senses.JarvisEars
import com.example.agent.senses.JarvisEyes
import com.example.agent.senses.JarvisVoice
import com.example.agent.senses.VoiceIdentitySubsystem
import com.example.data.FileArtifactEntity
import com.example.data.JarvisRepository
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicLong

enum class AgentMode {
    IDLE,
    LISTENING,
    ANALYZING,
    EXECUTING_ACTION,
    SPEAKING,
    INSPECTING_VISION
}

data class AgentLogEntry(
    val id: Long = idCounter.incrementAndGet(),
    val timestamp: Long = System.currentTimeMillis(),
    val tag: String, // BRAIN, SENSES, HANDS, ADAPTATION, VOICE
    val message: String
) {
    companion object {
        private val idCounter = AtomicLong(System.currentTimeMillis())
    }
}

class CognitiveCore(
    val context: Context,
    val repository: JarvisRepository,
    val sensors: DeviceSensors,
    val navigator: AppNavigator,
    val bridge: AccessibilityBridge,
    val perception: ScreenPerceptionEngine,
    val voice: JarvisVoice,
    val voiceIdentity: VoiceIdentitySubsystem,
    val eyes: JarvisEyes,
    private val scope: CoroutineScope
) {

    val antBeeEngine = AntBeeAdaptationEngine(repository)
    val reasoningEngine = GeminiReasoningEngine()

    lateinit var ears: JarvisEars

    private val _agentMode = MutableStateFlow(AgentMode.IDLE)
    val agentMode: StateFlow<AgentMode> = _agentMode.asStateFlow()

    private val _currentThought = MutableStateFlow("JARVIS online. All systems nominal.")
    val currentThought: StateFlow<String> = _currentThought.asStateFlow()

    private val _logs = MutableStateFlow<List<AgentLogEntry>>(emptyList())
    val logs: StateFlow<List<AgentLogEntry>> = _logs.asStateFlow()

    private val handler = Handler(Looper.getMainLooper())
    private var lastAutonomousVisionSpeakTime = 0L

    val autonomousConsciousnessActive = MutableStateFlow(true)

    val audioPlayer = AudioPlayerHelper(context)
    private val _activeFile = MutableStateFlow<DecodedFileResult?>(null)
    val activeFile: StateFlow<DecodedFileResult?> = _activeFile.asStateFlow()

    init {
        ears = JarvisEars(context) { recognizedText, avgEnergy ->
            onVoiceInputReceived(recognizedText, avgEnergy)
        }
        log("BRAIN", "Cognitive Core initialized. Autonomous body consciousness active.")

        // 1. Autonomous coordination: pause listening during speech, resume immediately after
        scope.launch {
            voice.isSpeaking.collect { isSpeaking ->
                if (isSpeaking) {
                    ears.pauseListeningForSpeaking()
                } else {
                    ears.resumeListeningAfterSpeaking()
                }
            }
        }

        // 2. Autonomous Screen Awareness Loop
        scope.launch {
            var lastPackage = ""
            bridge.activePackage.collect { newPkg ->
                if (newPkg.isNotBlank() && newPkg != lastPackage && newPkg != context.packageName) {
                    lastPackage = newPkg
                    val report = perception.analyzeCurrentScreen()
                    log("HANDS", "Autonomous observation: Opened ${report.appDisplayName} ($newPkg)")
                    _currentThought.value = "Observing ${report.appDisplayName}. Standing by to assist."
                }
            }
        }

        // 3. Autonomous Body Hardware Awareness
        scope.launch {
            var lastChargingState: Boolean? = null
            sensors.telemetry.collect { tele ->
                if (lastChargingState != null && lastChargingState != tele.isCharging) {
                    if (tele.isCharging) {
                        log("BODY", "Power engaged. Battery charging at ${tele.batteryPercent}%.")
                        voice.speak("Power connected, sir. Recharging battery cells.")
                    } else {
                        log("BODY", "Power disconnected. Operating on battery.")
                    }
                }
                lastChargingState = tele.isCharging
            }
        }

        // Automatically begin continuous listening without waiting for user taps
        ears.startListening()
    }

    suspend fun handleAutonomousVisionFrame(bitmap: android.graphics.Bitmap) {
        if (!autonomousConsciousnessActive.value) return
        if (_agentMode.value == AgentMode.SPEAKING || _agentMode.value == AgentMode.EXECUTING_ACTION) return

        val b64 = eyes.bitmapToBase64(bitmap)
        val visionAnalysis = reasoningEngine.analyzeVision(
            imageBase64 = b64,
            userQuery = "Observe and identify key objects, text, and environmental elements in view."
        )
        log("EYES", "Autonomous optic observation: $visionAnalysis")
        _currentThought.value = visionAnalysis

        val now = System.currentTimeMillis()
        if (now - lastAutonomousVisionSpeakTime > 25000 && visionAnalysis.isNotBlank() && !visionAnalysis.contains("error", ignoreCase = true)) {
            lastAutonomousVisionSpeakTime = now
            voice.speak(visionAnalysis.take(120))
        }
    }

    suspend fun attachAndDecodeFile(uri: Uri) {
        _agentMode.value = AgentMode.ANALYZING
        _currentThought.value = "Inspecting attached file data..."
        log("FILES", "Ingesting file from URI: $uri")

        val result = FileInspector.inspectAndDecode(context, uri)
        _activeFile.value = result

        // Record in Room DB
        repository.recordFileArtifact(
            FileArtifactEntity(
                uriString = uri.toString(),
                fileName = result.fileName,
                mimeType = result.mimeType,
                fileSize = result.fileSizeBytes,
                fileCategory = result.category.name,
                decodedSummary = result.decodedSummary,
                detailedMetadata = result.technicalMetadata.entries.joinToString("; ") { "${it.key}: ${it.value}" }
            )
        )

        // Neural multi-modal / semantic decoding
        val evaluation = when (result.category) {
            FileCategory.IMAGE, FileCategory.PDF, FileCategory.VIDEO -> {
                if (result.thumbnailBitmap != null) {
                    val b64 = eyes.bitmapToBase64(result.thumbnailBitmap)
                    val prompt = when (result.category) {
                        FileCategory.PDF -> "Read this rendered first page of the PDF '${result.fileName}'. Extract the title, author, table of contents or main text, and describe what this document contains."
                        FileCategory.VIDEO -> "Analyze this keyframe from video '${result.fileName}'. Describe the scene, visible entities, and action."
                        else -> "Analyze this image '${result.fileName}'. Describe what is shown, identify objects, persons, settings, and read any visible text."
                    }
                    reasoningEngine.analyzeVision(b64, prompt)
                } else {
                    result.decodedSummary
                }
            }
            FileCategory.DOCUMENT -> {
                if (!result.detailedTextContent.isNullOrBlank()) {
                    val preview = result.detailedTextContent.take(4000)
                    reasoningEngine.reasonAboutTask(
                        systemPrompt = "You are JARVIS. Summarize and analyze this attached office document for the user.",
                        userIntent = "Analyze document '${result.fileName}':\n\n$preview",
                        screenContext = "Office document inspection",
                        telemetryContext = sensors.getSummaryString()
                    )
                } else {
                    result.decodedSummary
                }
            }
            FileCategory.TEXT_CODE -> {
                if (!result.detailedTextContent.isNullOrBlank()) {
                    val preview = result.detailedTextContent.take(4000)
                    reasoningEngine.reasonAboutTask(
                        systemPrompt = "You are JARVIS. Summarize and analyze this attached code or text document for the user.",
                        userIntent = "Analyze file '${result.fileName}':\n\n$preview",
                        screenContext = "Text file inspection",
                        telemetryContext = sensors.getSummaryString()
                    )
                } else {
                    result.decodedSummary
                }
            }
            FileCategory.AUDIO -> {
                "Decoded audio asset '${result.fileName}'. ${result.decodedSummary}. Real playback is ready."
            }
            FileCategory.ARCHIVE -> {
                "Cataloged archive package '${result.fileName}'. ${result.decodedSummary}. File manifest decoded."
            }
            FileCategory.BINARY -> {
                "Decoded binary stream '${result.fileName}'. ${result.decodedSummary}. Hash verified."
            }
        }

        _agentMode.value = AgentMode.SPEAKING
        _currentThought.value = evaluation
        log("FILES", "Decoded ${result.fileName} (${result.category.name}): $evaluation")
        voice.speak("File loaded: ${result.fileName}. $evaluation")

        repository.recordEpisode(
            origin = "FILE_ATTACHMENT",
            perception = "Attached ${result.fileName} (${result.category.name})",
            action = "DECODE_FILE",
            outcome = evaluation,
            success = true
        )

        delay(1000)
        _agentMode.value = AgentMode.IDLE
    }

    fun clearActiveFile() {
        audioPlayer.stop()
        _activeFile.value = null
    }

    fun log(tag: String, message: String) {
        val entry = AgentLogEntry(tag = tag, message = message)
        _logs.value = listOf(entry) + _logs.value.take(49)
        Log.d("JARVIS-$tag", message)
    }

    private fun onVoiceInputReceived(speechText: String, speechEnergy: Float) {
        scope.launch {
            processCommand(speechText, origin = "VOICE", speechEnergy = speechEnergy)
        }
    }

    fun processCommand(
        command: String,
        origin: String = "UI",
        speechEnergy: Float = 0.5f
    ) {
        scope.launch {
            if (command.isBlank()) return@launch

            _agentMode.value = AgentMode.ANALYZING
            _currentThought.value = "Processing command: \"$command\""
            log("EARS", "Input received ($origin): \"$command\"")

            // 1. Voice Identity & Security Check
            if (voiceIdentity.isActionSensitive(command)) {
                log("BRAIN", "Sensitive directive detected. Initiating Voice Identity verification.")
                val authResult = voiceIdentity.authenticateVoice(speechEnergy)
                if (!authResult.isAuthorized) {
                    _agentMode.value = AgentMode.SPEAKING
                    val denialMsg = "Security protocol engaged. ${authResult.reason}. Directive halted for your protection."
                    _currentThought.value = denialMsg
                    voice.speak(denialMsg)
                    repository.recordEpisode(
                        origin = origin,
                        perception = command,
                        action = "SECURITY_HALT",
                        outcome = authResult.reason,
                        success = false
                    )
                    _agentMode.value = AgentMode.IDLE
                    return@launch
                } else {
                    log("BRAIN", "Voice authorized: ${authResult.userProfileName} (${(authResult.confidence * 100).toInt()}%)")
                }
            }

            // 2. Observe Screen & Body Telemetry
            val screenReport = perception.analyzeCurrentScreen()
            val telemetryStr = sensors.getSummaryString()
            log("SENSES", "Observing body: $telemetryStr")
            log("HANDS", "Observing screen: in ${screenReport.appDisplayName} (${screenReport.elementCount} elements)")

            // 3. Form Hypotheses using Ant/Bee Swarm Intelligence
            val hypotheses = formActionHypotheses(command, screenReport)
            val contextKey = "${screenReport.activePackage}:${command.take(20).trim().lowercase()}"

            val selection = antBeeEngine.evaluateAndSelectAction(contextKey, hypotheses)
            val chosen = selection.selectedHypothesis

            if (selection.wasPheromoneExploited) {
                log("ADAPTATION", "Exploited reinforced pheromone trail: ${chosen.rationale}")
            } else {
                log("ADAPTATION", "Formed hypothesis: ${chosen.actionType} (Confidence: ${(chosen.confidence * 100).toInt()}%)")
            }

            // 4. Gemini or Heuristic Reasoning confirmation
            _currentThought.value = chosen.rationale
            val activeFileContext = _activeFile.value?.let { file ->
                "Active Attached File: '${file.fileName}' (${file.category.name}, ${file.formattedSize}). " +
                "Summary: ${file.decodedSummary}. " +
                "Technical Metadata: ${file.technicalMetadata}. " +
                (file.detailedTextContent?.take(2000)?.let { "Content preview: $it" } ?: "")
            } ?: "No file currently attached."

            val speechReply = reasoningEngine.reasonAboutTask(
                systemPrompt = "You are JARVIS. Execute directive: $command. State your plan and speak naturally.",
                userIntent = "$command\n\n[FILE CONTEXT]\n$activeFileContext",
                screenContext = screenReport.summary,
                telemetryContext = telemetryStr
            )

            // 5. Execute Action through Phone Body (Hands & Intents)
            _agentMode.value = AgentMode.EXECUTING_ACTION
            val actionSuccess = executeHypothesis(chosen)

            // 6. Observe Outcome & Verify
            delay(500)
            val verificationSuccess = if (chosen.actionType == "SPEAK" || chosen.actionType == "SYSTEM_STATUS") {
                true
            } else {
                perception.verifyActionOutcome(screenReport) || actionSuccess
            }

            // 7. Reinforce Pheromone Trail & Learn
            antBeeEngine.recordOutcome(contextKey, chosen, verificationSuccess)
            log("ADAPTATION", if (verificationSuccess) "Trail reinforced with positive pheromone." else "Action encountered resistance. Trail decayed.")

            // 8. Speak Response to User
            _agentMode.value = AgentMode.SPEAKING
            val finalSpoken = if (actionSuccess) speechReply else "Sir, I encountered an issue completing that action. Would you like me to try an alternative approach?"
            _currentThought.value = finalSpoken
            voice.speak(finalSpoken)

            repository.recordEpisode(
                origin = origin,
                perception = command,
                action = "${chosen.actionType}:${chosen.parameter}",
                outcome = if (verificationSuccess) "Success: $finalSpoken" else "Failed to verify outcome",
                success = verificationSuccess
            )

            delay(1000)
            _agentMode.value = AgentMode.IDLE
        }
    }

    private fun formActionHypotheses(
        command: String,
        screen: com.example.agent.perception.ScreenStateReport
    ): List<ActionHypothesis> {
        val lower = command.lowercase()
        val list = mutableListOf<ActionHypothesis>()

        when {
            // Attached file commands
            _activeFile.value != null && (lower.contains("play") || lower.contains("listen")) && _activeFile.value?.canPlayAudio == true -> {
                list.add(ActionHypothesis("PLAY_ATTACHED_AUDIO", _activeFile.value!!.fileName, "Play attached audio track '${_activeFile.value!!.fileName}'", 0.96f))
            }
            _activeFile.value != null && (lower.contains("pause") || lower.contains("stop audio") || lower.contains("stop music")) && _activeFile.value?.canPlayAudio == true -> {
                list.add(ActionHypothesis("PAUSE_ATTACHED_AUDIO", "", "Pause currently playing audio", 0.96f))
            }
            _activeFile.value != null && (lower.contains("open file") || lower.contains("open document") || lower.contains("open in app") || lower.contains("view file")) -> {
                list.add(ActionHypothesis("OPEN_ATTACHED_FILE", _activeFile.value!!.fileName, "Open attached file in system application", 0.95f))
            }
            _activeFile.value != null && (lower.contains("what is this file") || lower.contains("explain file") || lower.contains("summarize file") || lower.contains("read file") || lower.contains("analyze file")) -> {
                list.add(ActionHypothesis("EXPLAIN_ATTACHED_FILE", _activeFile.value!!.fileName, "Analyze and explain attached file", 0.95f))
            }
            _activeFile.value != null && (lower.contains("detach file") || lower.contains("clear file") || lower.contains("remove file")) -> {
                list.add(ActionHypothesis("CLEAR_ATTACHED_FILE", "", "Detach file from working memory", 0.95f))
            }
            lower.contains("open maps") || lower.contains("google maps") -> {
                list.add(ActionHypothesis("LAUNCH_MAPS", "", "Launch real Google Maps application", 0.95f))
            }
            lower.contains("find") && (lower.contains("petrol") || lower.contains("gas") || lower.contains("station")) -> {
                list.add(ActionHypothesis("MAPS_SEARCH", "petrol station", "Search nearest petrol stations via Maps", 0.92f))
                list.add(ActionHypothesis("CLICK_TARGET", "Search", "Click search bar on screen", 0.75f))
            }
            lower.contains("navigate") || lower.contains("directions") -> {
                val dest = lower.substringAfter("navigate to", lower.substringAfter("directions to", "destination")).trim()
                list.add(ActionHypothesis("MAPS_SEARCH", dest, "Direct navigation to $dest", 0.90f))
            }
            lower.contains("youtube") -> {
                val q = lower.substringAfter("youtube", "").trim()
                list.add(ActionHypothesis("LAUNCH_YOUTUBE", q, "Access YouTube media player", 0.90f))
            }
            lower.contains("browse") || lower.contains("search web") || lower.contains("google ") -> {
                val q = lower.substringAfter("search web for", lower.substringAfter("google", command)).trim()
                list.add(ActionHypothesis("LAUNCH_BROWSER", q, "Perform real search on browser", 0.88f))
            }
            lower.contains("call") || lower.contains("phone") || lower.contains("dial") -> {
                val digits = lower.filter { it.isDigit() }
                list.add(ActionHypothesis("LAUNCH_DIALER", digits, "Launch device phone dialer", 0.85f))
            }
            lower.contains("camera") || lower.contains("take photo") -> {
                list.add(ActionHypothesis("LAUNCH_CAMERA", "", "Open phone hardware camera", 0.85f))
            }
            lower.contains("calculator") -> {
                list.add(ActionHypothesis("LAUNCH_CALCULATOR", "", "Open device calculator", 0.85f))
            }
            lower.contains("settings") -> {
                list.add(ActionHypothesis("LAUNCH_SETTINGS", "main", "Open Android system settings", 0.85f))
            }
            lower.contains("go home") || lower.contains("home screen") -> {
                list.add(ActionHypothesis("GLOBAL_HOME", "", "Navigate to Android Home", 0.90f))
            }
            lower.contains("go back") || lower.contains("back") -> {
                list.add(ActionHypothesis("GLOBAL_BACK", "", "Trigger system Back navigation", 0.90f))
            }
            lower.contains("scroll") -> {
                list.add(ActionHypothesis("SCROLL_FORWARD", "", "Scroll current screen down", 0.85f))
            }
            lower.contains("battery") || lower.contains("diagnostic") || lower.contains("status") -> {
                list.add(ActionHypothesis("SYSTEM_STATUS", "", "Read body diagnostic telemetry", 0.95f))
            }
            lower.contains("click") || lower.contains("tap") || lower.contains("press") -> {
                val target = lower.substringAfter("click", lower.substringAfter("tap", "")).trim()
                list.add(ActionHypothesis("CLICK_TARGET", target, "Click screen element matching '$target'", 0.80f))
            }
            lower.contains("type") || lower.contains("enter text") -> {
                val textToType = lower.substringAfter("type", "").trim()
                list.add(ActionHypothesis("TYPE_TEXT", textToType, "Type '$textToType' into editable field", 0.80f))
            }
            else -> {
                // Check if screen has matching button or if user mentioned an app name
                val targetElem = perception.findBestTargetForIntent(command)
                if (targetElem != null) {
                    val label = targetElem.text.ifBlank { targetElem.contentDescription }
                    list.add(ActionHypothesis("CLICK_TARGET", label, "Click matching screen element '$label'", 0.75f))
                }
                list.add(ActionHypothesis("LAUNCH_APP", command, "Launch app matching '$command'", 0.60f))
                list.add(ActionHypothesis("SPEAK", command, "Acknowledge and answer directly", 0.50f))
            }
        }
        return list
    }

    private suspend fun executeHypothesis(hypothesis: ActionHypothesis): Boolean = withContext(Dispatchers.Main) {
        log("HANDS", "Executing action: ${hypothesis.actionType} with parameter '${hypothesis.parameter}'")
        when (hypothesis.actionType) {
            "PLAY_ATTACHED_AUDIO" -> {
                _activeFile.value?.let { audioPlayer.loadAndPlay(it.uri, it.fileName) }
                true
            }
            "PAUSE_ATTACHED_AUDIO" -> {
                audioPlayer.stop()
                true
            }
            "OPEN_ATTACHED_FILE" -> {
                _activeFile.value?.let { FileInspector.openFileExternally(context, it.uri, it.mimeType) } ?: false
            }
            "EXPLAIN_ATTACHED_FILE" -> true
            "CLEAR_ATTACHED_FILE" -> {
                clearActiveFile()
                true
            }
            "LAUNCH_MAPS" -> navigator.launchGoogleMaps(hypothesis.parameter.ifBlank { null })
            "MAPS_SEARCH" -> navigator.launchGoogleMaps(hypothesis.parameter)
            "LAUNCH_YOUTUBE" -> navigator.launchYouTube(hypothesis.parameter.ifBlank { null })
            "LAUNCH_BROWSER" -> navigator.launchWebBrowser(hypothesis.parameter)
            "LAUNCH_DIALER" -> navigator.launchPhoneDialer(hypothesis.parameter.ifBlank { null })
            "LAUNCH_CAMERA" -> navigator.launchCamera()
            "LAUNCH_CALCULATOR" -> navigator.launchCalculator()
            "LAUNCH_SETTINGS" -> navigator.launchSettings(hypothesis.parameter)
            "LAUNCH_APP" -> navigator.launchAppByNameOrPackage(hypothesis.parameter)
            "GLOBAL_HOME" -> bridge.performHome()
            "GLOBAL_BACK" -> bridge.performBack()
            "SCROLL_FORWARD" -> bridge.scrollForward()
            "CLICK_TARGET" -> bridge.clickElementByTextOrDescription(hypothesis.parameter)
            "TYPE_TEXT" -> bridge.typeTextIntoFocusedOrFirstEditable(hypothesis.parameter)
            "SYSTEM_STATUS" -> {
                sensors.updateTelemetry()
                true
            }
            "SPEAK" -> true
            else -> false
        }
    }

    fun inspectCameraSurroundings(query: String = "What do you see in the surroundings?") {
        scope.launch {
            _agentMode.value = AgentMode.INSPECTING_VISION
            _currentThought.value = "Capturing optical feed for neural analysis..."
            log("EYES", "Engaging CameraX optical frame capture...")

            val bitmap = eyes.captureFrameBitmap()
            if (bitmap == null) {
                val err = "Camera optic feed not bound or permission pending."
                log("EYES", err)
                voice.speak("Sir, I cannot access the camera feed right now. Please confirm camera permissions.")
                _agentMode.value = AgentMode.IDLE
                return@launch
            }

            val b64 = eyes.bitmapToBase64(bitmap)
            log("EYES", "Frame digitized. Consulting multimodal vision cortex...")
            _currentThought.value = "Analyzing visual environment with Gemini..."

            val analysis = reasoningEngine.analyzeVision(b64, query)
            _agentMode.value = AgentMode.SPEAKING
            _currentThought.value = analysis
            log("BRAIN", "Vision analysis complete: $analysis")
            voice.speak(analysis)

            repository.recordEpisode(
                origin = "CAMERA",
                perception = "Visual inspection: $query",
                action = "INSPECT_VISION",
                outcome = analysis,
                success = true
            )

            delay(1000)
            _agentMode.value = AgentMode.IDLE
        }
    }
}
