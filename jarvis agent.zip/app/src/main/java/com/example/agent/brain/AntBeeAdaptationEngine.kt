package com.example.agent.brain

import com.example.data.JarvisRepository
import com.example.data.PheromoneTrailEntity
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

data class ActionHypothesis(
    val actionType: String, // LAUNCH_APP, CLICK_TARGET, TYPE_TEXT, SCROLL, GLOBAL_BACK, GLOBAL_HOME, INSPECT_VISION
    val parameter: String,
    val rationale: String,
    val confidence: Float
)

data class AdaptationCycleResult(
    val selectedHypothesis: ActionHypothesis,
    val wasPheromoneExploited: Boolean,
    val pheromoneStrength: Float,
    val alternativeHypothesesCount: Int
)

class AntBeeAdaptationEngine(private val repository: JarvisRepository) {

    val activeTrails: Flow<List<PheromoneTrailEntity>> = repository.pheromoneTrails

    suspend fun evaluateAndSelectAction(
        contextSignature: String,
        candidateHypotheses: List<ActionHypothesis>
    ): AdaptationCycleResult {
        // Consult pheromone trail for this context signature
        val existingTrail = repository.getTrail(contextSignature)

        if (existingTrail != null && existingTrail.pheromoneStrength >= 1.2f) {
            // High pheromone trail exists: EXPLOIT known path
            val parsedActions = parseActionJson(existingTrail.actionSequenceJson)
            val topSaved = parsedActions.firstOrNull()
            if (topSaved != null) {
                return AdaptationCycleResult(
                    selectedHypothesis = topSaved.copy(
                        rationale = "Exploited reinforced pheromone trail (Strength: %.2f, %d successes)".format(
                            existingTrail.pheromoneStrength,
                            existingTrail.successCount
                        )
                    ),
                    wasPheromoneExploited = true,
                    pheromoneStrength = existingTrail.pheromoneStrength,
                    alternativeHypothesesCount = candidateHypotheses.size
                )
            }
        }

        // EXPLORE: Rank candidate hypotheses based on confidence
        val sorted = candidateHypotheses.sortedByDescending { it.confidence }
        val selected = sorted.firstOrNull() ?: ActionHypothesis(
            actionType = "SPEAK",
            parameter = "I am observing the situation, sir. Awaiting further telemetry.",
            rationale = "No viable action hypothesis formed.",
            confidence = 0.5f
        )

        return AdaptationCycleResult(
            selectedHypothesis = selected,
            wasPheromoneExploited = false,
            pheromoneStrength = existingTrail?.pheromoneStrength ?: 1.0f,
            alternativeHypothesesCount = (sorted.size - 1).coerceAtLeast(0)
        )
    }

    suspend fun recordOutcome(
        contextSignature: String,
        hypothesis: ActionHypothesis,
        succeeded: Boolean
    ) {
        val actionJson = serializeHypotheses(listOf(hypothesis))
        repository.reinforceTrail(
            patternKey = contextSignature,
            actionSequenceJson = actionJson,
            success = succeeded
        )
    }

    private fun serializeHypotheses(list: List<ActionHypothesis>): String {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("actionType", item.actionType)
                put("parameter", item.parameter)
                put("rationale", item.rationale)
                put("confidence", item.confidence.toDouble())
            }
            array.put(obj)
        }
        return array.toString()
    }

    private fun parseActionJson(json: String): List<ActionHypothesis> {
        return try {
            val array = JSONArray(json)
            val list = mutableListOf<ActionHypothesis>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ActionHypothesis(
                        actionType = obj.getString("actionType"),
                        parameter = obj.getString("parameter"),
                        rationale = obj.optString("rationale", ""),
                        confidence = obj.optDouble("confidence", 0.8).toFloat()
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }
}
