package com.example

import android.app.Application
import com.example.agent.brain.CognitiveCore
import com.example.agent.hands.AccessibilityBridge
import com.example.agent.hands.AppNavigator
import com.example.agent.perception.ScreenPerceptionEngine
import com.example.agent.senses.DeviceSensors
import com.example.agent.senses.JarvisEyes
import com.example.agent.senses.JarvisVoice
import com.example.agent.senses.VoiceIdentitySubsystem
import com.example.data.JarvisDatabase
import com.example.data.JarvisRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class JarvisApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var database: JarvisDatabase
        private set

    lateinit var repository: JarvisRepository
        private set

    lateinit var cognitiveCore: CognitiveCore
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = JarvisDatabase.getInstance(this)
        repository = JarvisRepository(database.jarvisDao())

        val sensors = DeviceSensors(this, appScope)
        val voice = JarvisVoice(this)
        val navigator = AppNavigator(this)
        val bridge = AccessibilityBridge.instance
        val perception = ScreenPerceptionEngine(bridge)
        val voiceIdentity = VoiceIdentitySubsystem(repository)
        val eyes = JarvisEyes(this)

        cognitiveCore = CognitiveCore(
            context = this,
            repository = repository,
            sensors = sensors,
            navigator = navigator,
            bridge = bridge,
            perception = perception,
            voice = voice,
            voiceIdentity = voiceIdentity,
            eyes = eyes,
            scope = appScope
        )

        appScope.launch {
            voiceIdentity.loadProfile()
        }
    }

    companion object {
        lateinit var instance: JarvisApp
            private set
    }
}
