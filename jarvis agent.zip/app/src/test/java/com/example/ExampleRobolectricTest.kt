package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS", appName)
  }

  @Test
  fun `test file inspection on sample text file`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val tempFile = java.io.File(context.cacheDir, "sample_code.kt").apply {
      writeText("package com.sample\nfun main() {\n    println(\"JARVIS Agent Online\")\n}\n")
    }
    val uri = android.net.Uri.fromFile(tempFile)
    val decoded = com.example.agent.files.FileInspector.inspectAndDecode(context, uri)

    assertEquals(com.example.agent.files.FileCategory.TEXT_CODE, decoded.category)
    assertEquals("sample_code.kt", decoded.fileName)
    org.junit.Assert.assertTrue(decoded.detailedTextContent?.contains("JARVIS Agent Online") == true)
    org.junit.Assert.assertTrue(decoded.technicalMetadata.containsKey("Lines"))
  }
}
